#define SLOTS_TEST
#include <iostream>
#include "../native/slots.cpp"
#include "random-tests.h"
int main(){try { randomTests116(); return 0; } catch(...) { std::cerr << "FAIL random regression\n"; return 1; }}
