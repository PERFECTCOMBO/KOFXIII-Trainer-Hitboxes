static int pushes116=0,failAfter116=-1,clears116=0;
static void fakePush116(RecordDeque116* q,const unsigned char*){if(pushes116++==failAfter116)throw Failure{-9};q->count++;q->map=0x12340000+pushes116;q->size=8;}
static void fakeClear116(RecordDeque116* q){clears116++;q->map=q->size=q->count=q->offset=0;}
static void randomTests116(){
 // Exercise the production chooser with independent draws, including repeats.
 std::vector<int> two{0,1},actual;
 for(uint32_t draw:{0u,2u,1u,3u,4u,6u})actual.push_back(chooseRandom116(two,draw));
 require(actual==std::vector<int>({0,0,1,1,0,0}));
 require(chooseRandom116({4},123)==4);
 std::vector<int> five{0,1,2,3,4},fiveActual;
 for(uint32_t draw:{0u,4u,4u,2u,3u,2u,1u,3u})fiveActual.push_back(chooseRandom116(five,draw));
 require(fiveActual==std::vector<int>({0,4,4,2,3,2,1,3}));
 bool emptyRejected=false;try{chooseRandom116({},0);}catch(Failure f){emptyRejected=f.code==-3;}require(emptyRejected);
 auto prior=fixtureImage;fixtureImage=(uintptr_t)VirtualAlloc(nullptr,0xA20000,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);require(fixtureImage!=0);
 *(unsigned char*)(fixtureImage+0x594557)=1;*(uint32_t*)(fixtureImage+0x9e1de8)=(uint32_t)fixtureImage+0x4ba54c;
 unsigned char actors[2][1024]{};for(int p=0;p<2;p++){*(uint32_t*)(fixtureImage+0x9b6fe8+p*4)=(uint32_t)actors[p];*(uint32_t*)(actors[p]+0x1d4)=123+p;}
 pushRecord116=fakePush116;clearRecord116=fakeClear116;
 std::array<std::array<Stream,2>,5> bank;require(eligible116(bank,0).empty());bank[1][1].entries.resize(5);require(eligible116(bank,2)==std::vector<int>{1});bank[4][1].entries.resize(15);require(eligible116(bank,2)==std::vector<int>({1,4}));require(eligible116(bank,5)==std::vector<int>({1,4}));require(eligible116(bank,0)==std::vector<int>({1,4}));
 for(int fail=0;fail<3;fail++){pushes116=clears116=0;failAfter116=fail;auto old0=read((uintptr_t)actors[0],1024),old1=read((uintptr_t)actors[1],1024);bool failed=false;try{replaceRecord116(bank[4]);}catch(Failure){failed=true;}require(failed&&clears116==2&&read((uintptr_t)actors[0],1024)==old0&&read((uintptr_t)actors[1],1024)==old1);}
 failAfter116=-1;replaceRecord116(bank[4]);require(word((uintptr_t)actors[1]+0x1e4)==3&&word((uintptr_t)actors[0]+0x1e4)==0);require(word((uintptr_t)actors[0]+0x1d4)==123&&word((uintptr_t)actors[1]+0x1d4)==124);
 replaceRecord116(bank[1]);require(word((uintptr_t)actors[1]+0x1e4)==1);
 *(unsigned char*)(fixtureImage+0x594557)=0;bool refused=false;try{replaceRecord116(bank[1]);}catch(Failure){refused=true;}require(refused);
 VirtualFree((void*)fixtureImage,0,MEM_RELEASE);fixtureImage=prior;
 std::cout<<"PASS116 nonempty selection, independent selection permits repeats, variable counts, precommit allocation failure, opaque words and offline guard\n";
}
