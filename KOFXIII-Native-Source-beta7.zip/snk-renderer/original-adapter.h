#include "original-loop.h"
// Values recovered from the original static palette initializer, 7a90f4-7a926a.
// Fourth component is border width in world units, not opacity.
static const float originalPalette[6][4]={{0,0,1,4},{1,1,0,4},{0,1,0,2},{1,0,0,2},{1,0,1,2},{1,1,1,2}};
struct OriginalEntity {unsigned char reserved[0x5c];const Frame* frame;};
struct OriginalIterator {const Box* data;unsigned index,count;};
struct OriginalDevice {IDirect3DDevice9* device;unsigned draws;float color[4],rect[4];};
static void* __fastcall originalBegin(const Frame** list,void*,OriginalIterator* out){out->data=(*list)->boxes;out->index=0;out->count=(*list)->count;return out;}
static void* __fastcall originalEnd(const Frame** list,void*,OriginalIterator* out){originalBegin(list,nullptr,out);out->index=out->count;return out;}
static void __fastcall originalAdvance(OriginalIterator* it,void*){++it->index;}
static bool __fastcall originalDifferent(OriginalIterator* it,void*,OriginalIterator* other){return it->data!=other->data||it->index!=other->index;}
static const Box* __fastcall originalDereference(OriginalIterator* it,void*){return it->data+it->index;}
static unsigned __cdecl originalMin(const unsigned* a,const unsigned* b){return *a<*b?*a:*b;}
static void* __fastcall originalVector(float* self,void*,float x,float y,float z,float w){self[0]=x;self[1]=y;self[2]=z;self[3]=w;return self;}
static void __fastcall originalDestroy(void*,void*){}
static void __fastcall originalConstant(OriginalDevice* context,void*,unsigned slot,const float* value){
 if(slot==4)memcpy(context->color,value,16);if(slot==5)memcpy(context->rect,value,16);
 if(context->device)context->device->SetVertexShaderConstantF(slot,value,1);
}
static void __fastcall originalDraw(OriginalDevice* context,void*,unsigned primitive,unsigned start,unsigned vertices){
 if(primitive!=4||start!=0||vertices!=10)return;
 ++context->draws;
 if(context->device)context->device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP,vertices-2,originalVertices,sizeof(originalVertices[0]));
}
using OriginalLoopFn=void(__thiscall*)(OriginalEntity*,OriginalDevice*);
static OriginalLoopFn snkLoop;
static bool prepareOriginalLoop(const float (*palette)[4]=originalPalette){
 if(snkLoop)return true;
 const unsigned char prologue[]={0x55,0x8b,0xec,0x83,0xec,0x60,0x89,0x4d,0xf0};
 const unsigned char epilogue[]={0x8b,0xe5,0x5d,0xc2,0x04,0x00};
 size_t n=sizeof(prologue)+sizeof(originalLoop)+sizeof(epilogue);
 auto code=(unsigned char*)VirtualAlloc(nullptr,n,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);if(!code)return false;
 memcpy(code,prologue,sizeof(prologue));auto body=code+sizeof(prologue);memcpy(body,originalLoop,sizeof(originalLoop));memcpy(body+sizeof(originalLoop),epilogue,sizeof(epilogue));
 *(DWORD*)(body+palettePatch)=(DWORD)palette;
 for(auto c:originalCalls){void* target=nullptr;switch(c.address){
  case 0x7ac440:target=(void*)&originalEnd;break;case 0x7ac100:target=(void*)&originalBegin;break;
  case 0x7ab560:target=(void*)&originalAdvance;break;case 0x7ab040:target=(void*)&originalDifferent;break;
  case 0x7ab300:target=(void*)&originalDereference;break;case 0x4a10d0:target=(void*)&originalMin;break;
  case 0x5133e0:target=(void*)&originalVector;break;case 0x51eb90:case 0x7aaaf0:target=(void*)&originalDestroy;break;
  case 0x8d7590:target=(void*)&originalConstant;break;case 0x8d5c40:target=(void*)&originalDraw;break;
 }
 if(!target){VirtualFree(code,0,MEM_RELEASE);return false;}
 *(DWORD*)(body+c.offset+1)=(DWORD)((uintptr_t)target-(uintptr_t)(body+c.offset+5));
 }
 DWORD old;if(!VirtualProtect(code,n,PAGE_EXECUTE_READ,&old)){VirtualFree(code,0,MEM_RELEASE);return false;}
 FlushInstructionCache(GetCurrentProcess(),code,n);snkLoop=(OriginalLoopFn)code;return true;
}
