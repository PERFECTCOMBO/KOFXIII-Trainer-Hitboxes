param([switch]$TrainerOnly)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$vs=& "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe" -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if(!$vs){throw 'Install Visual Studio C++ build tools and the Windows SDK.'}
if(!$TrainerOnly -and (!(Test-Path "$root\snk-renderer\original-loop.h") -or !(Test-Path "$root\snk-renderer\original-shaders.h"))){throw 'Run extract-snk.py first, or use -TrainerOnly.'}
New-Item -ItemType Directory -Force "$root\build" | Out-Null
$commands=@(
 '@echo off',
 "call `"$vs\VC\Auxiliary\Build\vcvars32.bat`" >nul",
 "cd /d `"$root\build`"",
 "cl /nologo /LD /MT /O2 /EHsc /std:c++17 `"$root\native\slots.cpp`" /link /DEF:`"$root\native\slots.def`" /OUT:KOF13RecordingSlots.dll /MACHINE:X86",
 'if errorlevel 1 exit /b 1',
 "cl /nologo /LD /MT /O2 /EHsc /std:c++17 `"$root\native\chain-loader.cpp`" /link /DEF:`"$root\native\dinput8.def`" /OUT:KOF13InputChain.dll /MACHINE:X86",
 'if errorlevel 1 exit /b 1',
 "cl /nologo /MT /O2 /EHsc /std:c++17 `"$root\tests\random.cpp`" /Fe:random-tests.exe",
 'if errorlevel 1 exit /b 1',
 'random-tests.exe',
 'if errorlevel 1 exit /b 1')
if(!$TrainerOnly){$commands+=@(
 "cl /nologo /LD /MT /O2 /EHsc /std:c++17 `"$root\native\renderer.cpp`" /link /OUT:KOF13NativeHitboxes.dll /MACHINE:X86",
 'if errorlevel 1 exit /b 1',
 "cl /nologo /LD /MT /O2 /EHsc /std:c++17 `"$root\native\loader.cpp`" /link /DEF:`"$root\native\dinput8.def`" /OUT:dinput8.dll /MACHINE:X86",
 'if errorlevel 1 exit /b 1')}
$commands | Set-Content "$root\build\compile.cmd" -Encoding ASCII
& $env:ComSpec /c "$root\build\compile.cmd"
if($LASTEXITCODE -ne 0){throw 'Build or regression test failed.'}
Write-Host 'Build and regression test passed. Output is in build/. No game files were changed.'
