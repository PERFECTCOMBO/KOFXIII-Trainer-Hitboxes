"""Generate excluded SNK headers locally from verified user-supplied files."""
from pathlib import Path
import argparse, hashlib, struct
import pefile, unicorn, capstone
from unicorn.x86_const import *
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--debug-exe',type=Path,required=True)
parser.add_argument('--shader-dir',type=Path,required=True)
a=parser.parse_args()
def verified(path,expected):
 data=path.read_bytes()
 if hashlib.sha256(data).hexdigest()!=expected:
  raise SystemExit('Unsupported input SHA-256: '+path.name)
 return data
verified(a.debug_exe,'d2e8e374f844f477874fa47cec20a8b66101ec1fb903ada2512cb926a3c1d806')
p=pefile.PE(str(a.debug_exe));u=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_32)
u.mem_map(0x400000,(p.OPTIONAL_HEADER.SizeOfImage+0xfff)&~0xfff);u.mem_write(0x400000,p.get_memory_mapped_image());u.mem_map(0x2000000,0x10000);u.mem_map(0x3000000,0x10000)
u.reg_write(UC_X86_REG_EBP,0x2008000);u.reg_write(UC_X86_REG_ESP,0x2007000)
verts={}
def hook(uc,a,n,data):
 if a==0x7ab0e0:
  sp=uc.reg_read(UC_X86_REG_ESP);ret,idx=struct.unpack('<II',uc.mem_read(sp,8));uc.reg_write(UC_X86_REG_EAX,0x3000000+idx*16);uc.reg_write(UC_X86_REG_ESP,sp+8);uc.reg_write(UC_X86_REG_EIP,ret)
 elif a==0x529870:
  sp=uc.reg_read(UC_X86_REG_ESP);ret=struct.unpack('<I',uc.mem_read(sp,4))[0];dst=uc.reg_read(UC_X86_REG_ECX);v=bytes(uc.mem_read(sp+4,16));verts[(dst-0x3000000)//16]=struct.unpack('<4f',v);uc.mem_write(dst,v);uc.reg_write(UC_X86_REG_EAX,dst);uc.reg_write(UC_X86_REG_ESP,sp+20);uc.reg_write(UC_X86_REG_EIP,ret)
 elif not 0x7a86d3<=a<0x7a8c40:
  print('stop',hex(a));uc.emu_stop()
u.hook_add(unicorn.UC_HOOK_CODE,hook);u.emu_start(0x7a86d3,0x7a8c40,count=5000)

if set(verts)!=set(range(18)): raise SystemExit('Geometry extraction failed')
loop=p.get_data(0x7a9290-0x400000,0x122)
md=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_32)
calls=[(i.address-0x7a9290,int(i.op_str,16)) for i in md.disasm(loop,0x7a9290) if i.mnemonic=='call']
if len(calls)!=13: raise SystemExit('Unexpected call layout')
out=Path(__file__).resolve().parent/'snk-renderer'
header='// Generated SNK material: excluded from the project MIT license.\n'
header+='static const unsigned char originalLoop[]={'+','.join(hex(x) for x in loop)+'};\n'
header+='static const unsigned palettePatch=127;\n'
header+='static const float originalVertices[18][4]={'+','.join('{'+','.join(str(float(v))+'f' for v in verts[i])+'}' for i in range(18))+'};\n'
header+='struct OriginalCall{unsigned offset,address;};\n'
header+='static const OriginalCall originalCalls[]={'+','.join('{'+hex(o)+','+hex(t)+'}' for o,t in calls)+'};\n'
shaders='// Generated SNK material: excluded from the project MIT license.\n'
for filename,name,digest in [('collision.vso','snkVertexShader','e453acb5c24668cb3f9a3fdfe445d8a59b9996b4906f6961603907d3632daee7'),('collision.pso','snkPixelShader','9a4f78e1e16286048ae9bf01cf2f654c15b38119c74d809d3a21d2cb3f46e52e')]:
 data=verified(a.shader_dir/filename,digest)
 values=struct.unpack('<'+'I'*(len(data)//4),data)
 shaders+='static const DWORD '+name+'[]={'+','.join(hex(x) for x in values)+'};\n'
(out/'original-loop.h').write_text(header)
(out/'original-shaders.h').write_text(shaders)
print('Generated local headers. Do not commit these proprietary files.')
