#include "counter-core.h"
#include "recorded-recovery.h"
static RecordedRecovery125 recovery125;
extern "C" __declspec(dllexport) Counter119 counter119;
Counter119 counter119;
static DWORD counterThread119=0;
static uintptr_t counterOriginal119=0;
static bool counterHook119=false;
static unsigned __cdecl counterInput119(uintptr_t actor,unsigned mask){
 try{
  if(!counter119.mode&&!recovery125.mode)return mask;
  if(GetCurrentThreadId()!=counterThread119)return mask;
  guard();
  if(read(image()+0x99e7ec,1)[0]||read(image()+0x9b6ff8,1)[0]){counter119.clear();recovery125.cancel();return mask;}
  if(actor!=word(image()+0x9b6fec))return mask;
  if(word(actor+0x20)!=18){counter119.clear();recovery125.cancel();return mask;}
  auto wrapper=word(actor+0x30),core=word(wrapper+8);require(word(core)==image()+0x4ae8bc);
  auto b=word(core+8);
  if(recovery125.mode){recovery125.observe((unsigned)actor,(unsigned)b,word(b+0xa0),word(b+0xa4),word(b+0x1e4));return mask;}
  return mask; // legacy fixed LP injection removed from this candidate
 }catch(...){counter119.mode=0;counter119.clear();recovery125.cancel();return mask;}
}
#ifndef SLOTS_TEST
__declspec(naked) static void counterStub119(){
 __asm {
  pushfd
  pushad
  push edi
  push ecx
  call counterInput119
  add esp,8
  mov [esp],eax
  mov [esp+40],eax
  popad
  popfd
  jmp dword ptr [counterOriginal119]
 }
}
static void counterInstall119(){
 if(counterHook119)return;
 auto site=image()+0x150b7f;require(read(site,5)==Bytes({0xe8,0x7c,0x34,0,0}),-15);
 counterOriginal119=image()+0x154000;
 unsigned char patch[5]={0xe8};auto displacement=(uint32_t)((uintptr_t)&counterStub119-site-5);memcpy(patch+1,&displacement,4);
 DWORD old;require(VirtualProtect((void*)site,5,PAGE_EXECUTE_READWRITE,&old)!=0);
 memcpy((void*)site,patch,5);DWORD ignored;VirtualProtect((void*)site,5,old,&ignored);FlushInstructionCache(GetCurrentProcess(),(void*)site,5);counterHook119=true;
}
#else
static void counterInstall119(){}
#endif
extern "C" __declspec(dllexport) int __cdecl KOFCounterBridge(void* state){
 int result=-9;auto l=(uintptr_t)state;
 try{
  auto base=word(l+12);require(word(l+8)>=base+8&&word(base+4)==3);float mode;auto arg=read(base,4);memcpy(&mode,arg.data(),4);require(mode>=-1&&mode<=0&&mode==(int)mode);
  if(mode>=0){verifyBuild();guard();if(mode>0)require(read(image()+0x99e7ec,1)[0]&&read(image()+0x9b6ff8,1)[0]);
   if(mode>0){auto actor=word(image()+0x9b6fec);require(word(actor+0x20)==18,-13);counterInstall119();}
   counter119.mode=(unsigned)mode;counter119.clear();counterThread119=GetCurrentThreadId();
  }
  result=(int)counter119.mode;
 }catch(Failure e){result=e.code;}catch(...){result=-9;}
 auto top=word(l+8);valid(top,8,true);float value=(float)result;uint32_t type=3;memcpy((void*)top,&value,4);memcpy((void*)(top+4),&type,4);*(uint32_t*)(l+8)=top+8;return 1;
}

extern "C" __declspec(dllexport) int __cdecl KOFReversalBridge(void* state){
 int result=-9;auto l=(uintptr_t)state;
 try{
  auto base=word(l+12);require(word(l+8)>=base+8&&word(base+4)==3);
  float command;auto bytes=read(base,4);memcpy(&command,bytes.data(),4);
  require(command>=-1&&command<=3&&command==(int)command);
  if(command==0){recovery125.cancel();counter119.mode=0;counter119.clear();result=0;}
  else {verifyBuild();guard();
   if(command==-1){result=(int)recovery125.take();if(!result&&!recovery125.mode)result=-17;}
   else {recovery125.cancel();counter119.mode=0;counter119.clear();
    require(command!=2,-16);auto actor=word(image()+0x9b6fec);require(word(actor+0x20)==18,-13);
    counterInstall119();counterThread119=GetCurrentThreadId();require(recovery125.arm((unsigned)command));result=1;
   }
  }
 }catch(Failure e){recovery125.cancel();result=e.code;}catch(...){recovery125.cancel();result=-9;}
 auto top=word(l+8);valid(top,8,true);float value=(float)result;uint32_t type=3;
 memcpy((void*)top,&value,4);memcpy((void*)(top+4),&type,4);*(uint32_t*)(l+8)=top+8;return 1;
}
