#pragma once
// A menu operation is staged only; the paused poll owns all native dispatch.
// No cross-thread submission: ownership and epoch are checked on consumption.
class MenuRequest {
 bool pending_=false;
 int action_=-1;
 uint64_t epoch_=0;
 uint32_t thread_=0,tick_=0;
public:
 bool pending()const{return pending_;}
 void cancel(){pending_=false;action_=-1;epoch_=0;thread_=tick_=0;}
 bool submit(int action,uint64_t epoch,uint32_t tick,uint32_t thread){
  // Conflicting edges invalidate the first request as well.
  if(pending_||action<0||action>4||!thread){cancel();return false;}
  pending_=true;action_=action;epoch_=epoch;tick_=tick;thread_=thread;return true;
 }
 int take(uint64_t epoch,uint32_t tick,uint32_t thread,bool allowed){
  if(!pending_)return -1;
  int action=action_;bool valid=allowed&&epoch==epoch_&&thread==thread_&&
    uint32_t(tick-tick_)<=1000;cancel();return valid?action:-1;
 }
};
