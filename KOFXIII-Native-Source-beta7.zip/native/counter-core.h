#pragma once
// Conservative response after a measured recovery transition, not a claim of earliest legality.
struct Counter119 {
 unsigned mode=0, actor=0,body=0; bool block=false,wake=false,held=false;
 unsigned pulses=0,starts=0,pending=0;
 void clear(){block=wake=held=false;pending=0;}
 unsigned step(unsigned who,unsigned address,unsigned action,unsigned primary,unsigned secondary,unsigned timer,unsigned flags,unsigned mask){
  if(who!=actor||address!=body){clear();actor=who;body=address;}
  if(pending){if(action==68&&primary==45&&timer==1){++starts;pending=0;}else if(--pending==0){} }
  if(!mode){clear();return mask;}
  if(primary==80&&secondary==80)block=true;
  if(primary==109&&secondary==109)wake=true;
  bool fire=!(flags&8)&&!held&&(((mode&1)&&block&&primary==80&&secondary==72)||((mode&2)&&wake&&primary==109&&secondary==1));
  if(primary!=80)block=false;if(primary!=109)wake=false;
  if(primary!=80&&primary!=109)held=false;
  if(fire){held=true;block=wake=false;++pulses;pending=30;return 0x10000;}
  return mask;
 }
};
