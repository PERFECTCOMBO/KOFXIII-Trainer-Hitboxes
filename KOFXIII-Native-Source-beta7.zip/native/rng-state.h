// Test95 candidate: script/game PRNG omitted by the observed native archive.
// Capture and restore only inside the paused offline menu callback.
struct Rng95 {Bytes data,hash;};
static void validateRng95(const Rng95& r){
 require(r.data.size()==40,-14);require(digest(r.data)==r.hash,-5);
 uint32_t index=0;memcpy(&index,r.data.data()+36,4);require(index<8,-14);
}
#ifdef SLOTS_TEST
static Bytes fixtureRng95(40,0);
#endif
static Rng95 captureRng95(){
 Rng95 r;
#ifdef SLOTS_TEST
 r.data=fixtureRng95;
#else
 require(read(image()+0x311ef0,16)==Bytes({0x56,0x8b,0xf1,0xb9,0x5e,0x24,0xb5,0x2a,0x57,0x8b,0x46,0x24,0x40,0x83,0xe0,0x7}),-8);
 r.data=read(image()+0x5943f4,40);
#endif
 r.hash=digest(r.data);validateRng95(r);return r;
}
static void restoreRng95(const Rng95& r){
 validateRng95(r);captureRng95(); // validate destination/build before any write
#ifdef SLOTS_TEST
 fixtureRng95=r.data;
#else
 auto address=image()+0x5943f4;valid(address,40,true);memcpy((void*)address,r.data.data(),40);
#endif
 require(captureRng95().data==r.data,-17);
}
