#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
#include <vector>
#include <array>
#include <algorithm>
#include <set>
#include <string>
#include <fstream>
#include <cstdint>
#include <cstring>
#include <stdexcept>
#pragma comment(lib,"advapi32.lib")
using Bytes=std::vector<unsigned char>;
static const char fingerprint[]="E7718F5C553DE852135DDEF5833A7BB6EAFD05508D1206AC6F3CE7767B474835";
struct Failure {int code;};
static void require(bool ok,int code=-9){if(!ok)throw Failure{code};}
static Bytes digest(const Bytes& b){HCRYPTPROV p=0;HCRYPTHASH h=0;require(CryptAcquireContextW(&p,0,0,PROV_RSA_AES,CRYPT_VERIFYCONTEXT)!=0);if(!CryptCreateHash(p,CALG_SHA_256,0,0,&h)){CryptReleaseContext(p,0);throw Failure{-9};}Bytes out(32);DWORD n=32;bool ok=CryptHashData(h,b.data(),(DWORD)b.size(),0)&&CryptGetHashParam(h,HP_HASHVAL,out.data(),&n,0);CryptDestroyHash(h);CryptReleaseContext(p,0);require(ok);return out;}
static std::wstring directory(){wchar_t path[32768];require(GetModuleFileNameW(nullptr,path,32768)>0);std::wstring s(path);return s.substr(0,s.find_last_of(L"\\/"));}
static Bytes fileRead(const std::wstring& path,size_t limit){std::ifstream f(path,std::ios::binary|std::ios::ate);require(!!f,-4);auto n=f.tellg();require(n>=0&&(size_t)n<=limit,-5);Bytes b((size_t)n);f.seekg(0);if(!b.empty())f.read((char*)b.data(),b.size());require(!!f,-5);return b;}
static void verifyBuild(){
#ifdef SLOTS_TEST
 return;
#endif
 static bool verified=false;if(verified)return;wchar_t path[32768];require(GetModuleFileNameW(nullptr,path,32768)>0);auto d=digest(fileRead(path,64*1024*1024));std::string hex;for(auto v:d){hex+="0123456789ABCDEF"[v>>4];hex+="0123456789ABCDEF"[v&15];}require(hex==fingerprint,-8);verified=true;}
static void valid(uintptr_t p,size_t n,bool write=false){require(p>=0x10000&&n<=1024*1024&&p+n>=p);auto end=p+n;while(p<end){MEMORY_BASIC_INFORMATION m{};require(VirtualQuery((void*)p,&m,sizeof(m))==sizeof(m));require(m.State==MEM_COMMIT&&!(m.Protect&(PAGE_GUARD|PAGE_NOACCESS)));auto protection=m.Protect&255;require(protection==PAGE_READONLY||protection==PAGE_READWRITE||protection==PAGE_WRITECOPY||protection==PAGE_EXECUTE_READ||protection==PAGE_EXECUTE_READWRITE||protection==PAGE_EXECUTE_WRITECOPY);if(write)require(protection==PAGE_READWRITE||protection==PAGE_WRITECOPY||protection==PAGE_EXECUTE_READWRITE||protection==PAGE_EXECUTE_WRITECOPY);auto next=(uintptr_t)m.BaseAddress+m.RegionSize;require(next>p);p=next;}}
static Bytes read(uintptr_t p,size_t n){valid(p,n);return Bytes((unsigned char*)p,(unsigned char*)p+n);}
static uint32_t word(uintptr_t p){auto b=read(p,4);uint32_t v;memcpy(&v,b.data(),4);return v;}
#ifdef SLOTS_TEST
static uintptr_t fixtureImage;
#endif
static uintptr_t image(){
#ifdef SLOTS_TEST
return fixtureImage;
#else
return (uintptr_t)GetModuleHandleW(nullptr);
#endif
}
static void guard(){auto b=image();require(read(b+0x594557,1)[0]==1,-1);require(word(b+0x999178)==0,-2);auto r=b+0x9e1de8;require(word(r)==b+0x4ba54c,-8);require(read(r+0x1c3c,1)[0]==0,-1);for(int i=0;i<9;i++)require(read(r+0x30b20+i*0xd8,1)[0]==0,-1);}
struct Stream{Bytes entries;std::vector<uintptr_t> addresses;};
struct Snapshot{std::array<Stream,2> players;std::vector<std::pair<uintptr_t,Bytes>> checks;};
static Snapshot capture(){guard();Snapshot s;auto remember=[&](uintptr_t a,size_t n){auto b=read(a,n);s.checks.push_back({a,b});return b;};auto actors=image()+0x9b6fe8;remember(actors,8);std::set<uintptr_t> used;
 for(int p=0;p<2;p++){auto actor=word(actors+p*4);require(actor>=0x10000&&actor<=0x7fffffff);auto header=(uintptr_t)actor+0x1d4;remember(header,20);auto map=word(header+4),size=word(header+8),offset=word(header+12),count=word(header+16);require(count<=36000);if(!count)continue;require(size>=8&&size<=65536&&!(size&(size-1))&&count<=size*2);remember(map,size*4);for(uint32_t i=0;i<count;i++){uint32_t index=offset+i;auto block=word(map+((index>>1)&(size-1))*4);require(block>=0x10000&&block<=0x7ffffff7);auto a=(uintptr_t)block+(index&1)*8;require(used.insert(a).second);auto e=remember(a,5);require(e[4]<=1);s.players[p].entries.insert(s.players[p].entries.end(),e.begin(),e.end());s.players[p].addresses.push_back(a);}}
 require(!s.players[0].entries.empty()||!s.players[1].entries.empty(),-3);guard();for(auto& c:s.checks)require(read(c.first,c.second.size())==c.second);return s;}
static void append32(Bytes& b,uint32_t v){for(int i=0;i<4;i++)b.push_back((unsigned char)(v>>(8*i)));}
static uint32_t take32(const Bytes& b,size_t& at){require(at+4<=b.size(),-5);uint32_t v=0;for(int i=0;i<4;i++)v|=(uint32_t)b[at++]<<(i*8);return v;}
static Bytes encode(const std::array<Stream,2>& players){Bytes b;append32(b,0x3152334b);append32(b,1);b.push_back(64);b.insert(b.end(),fingerprint,fingerprint+64);for(auto& s:players){require(s.entries.size()%5==0&&s.entries.size()/5<=36000,-5);append32(b,(uint32_t)s.entries.size()/5);b.insert(b.end(),s.entries.begin(),s.entries.end());}auto d=digest(b);b.insert(b.end(),d.begin(),d.end());return b;}
static std::array<Stream,2> decode(Bytes b){require(b.size()>=113&&b.size()<=361024,-5);Bytes checksum(b.end()-32,b.end());b.resize(b.size()-32);require(digest(b)==checksum,-5);size_t at=0;require(take32(b,at)==0x3152334b&&take32(b,at)==1,-5);require(b[at++]==64&&at+64<=b.size(),-5);require(memcmp(b.data()+at,fingerprint,64)==0,-5);at+=64;std::array<Stream,2> out;for(auto& s:out){auto n=take32(b,at);require(n<=36000&&at+(size_t)n*5<=b.size(),-5);s.entries.assign(b.begin()+at,b.begin()+at+n*5);at+=n*5;for(size_t i=4;i<s.entries.size();i+=5)require(s.entries[i]<=1,-5);}require(at==b.size(),-5);return out;}
static void saveFile(const std::wstring& path,const Bytes& data){auto tmp=path+L".tmp";HANDLE f=CreateFileW(tmp.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);require(f!=INVALID_HANDLE_VALUE,-7);DWORD n=0;bool ok=WriteFile(f,data.data(),(DWORD)data.size(),&n,nullptr)&&n==data.size()&&FlushFileBuffers(f);CloseHandle(f);if(!ok){DeleteFileW(tmp.c_str());throw Failure{-7};}if(GetFileAttributesW(path.c_str())!=INVALID_FILE_ATTRIBUTES){ok=ReplaceFileW(path.c_str(),tmp.c_str(),(path+L".bak").c_str(),0,nullptr,nullptr)!=0;}else ok=MoveFileExW(tmp.c_str(),path.c_str(),MOVEFILE_WRITE_THROUGH)!=0;if(!ok){DeleteFileW(tmp.c_str());throw Failure{-7};}}
#include "random-recording.h"
// Called synchronously by the paused Training menu's Lua coroutine. No worker,
// hooks, buffer resizing, foreign allocations in game deques, or input injection.
static int execute(int action,int slot){require(slot>=1&&slot<=5,-9);verifyBuild();guard();if(action==3||action==4)return randomRecord116(action,slot);auto folder=directory()+L"\\KOF13RecordingSlots";auto path=folder+L"\\standard-"+std::to_wstring(slot)+L".k13rec";if(action==0)return GetFileAttributesW(path.c_str())==INVALID_FILE_ATTRIBUTES?3:4;auto current=capture();if(action==1){require(CreateDirectoryW(folder.c_str(),nullptr)||GetLastError()==ERROR_ALREADY_EXISTS,-7);saveFile(path,encode(current.players));return 1;}require(action==2,-9);auto saved=decode(fileRead(path,361024));for(int p=0;p<2;p++)require(saved[p].entries.size()==current.players[p].entries.size(),-6);guard();for(auto& c:current.checks)require(read(c.first,c.second.size())==c.second);for(auto& s:current.players)for(auto a:s.addresses)valid(a,5,true);
 for(int p=0;p<2;p++)for(size_t i=0;i<current.players[p].addresses.size();i++)memcpy((void*)current.players[p].addresses[i],saved[p].entries.data()+i*5,5);
 bool ok=true;for(int p=0;p<2;p++)for(size_t i=0;i<current.players[p].addresses.size();i++)if(memcmp((void*)current.players[p].addresses[i],saved[p].entries.data()+i*5,5))ok=false;
 if(!ok){for(int p=0;p<2;p++)for(size_t i=0;i<current.players[p].addresses.size();i++)memcpy((void*)current.players[p].addresses[i],current.players[p].entries.data()+i*5,5);throw Failure{-9};}return 2;}
// This build uses 8-byte TValue (float32 + type), top +8, base +12.
// Lua's C-call contract reserves at least LUA_MINSTACK slots for this result.
extern "C" __declspec(dllexport) int __cdecl KOFRecordingBridge(void* state){int result=-9;uintptr_t l=(uintptr_t)state;try{auto base=word(l+12),top=word(l+8);require(top>=base+16);require(word(base+4)==3&&word(base+12)==3);float action,slot;auto args=read(base,16);memcpy(&action,args.data(),4);memcpy(&slot,args.data()+8,4);require(action>=0&&action<=4&&slot>=1&&slot<=5&&action==(int)action&&slot==(int)slot);result=execute((int)action,(int)slot);}catch(Failure e){result=e.code;}catch(...){result=-9;}auto top=word(l+8);valid(top,8,true);float f=(float)result;uint32_t type=3;memcpy((void*)top,&f,4);memcpy((void*)(top+4),&type,4);*(uint32_t*)(l+8)=top+8;return 1;}

// Narrow replacement for the compiled-out Lua loadlib callback. Only our exact
// module/symbol pair is supplied; every other request follows the original stub.
#include "hitbox-control.h"
#include "visibility.h"
#include "setup.h"
#include "counter-attack.h"
static int (__cdecl *originalLoadlib)(void*);
static std::string luaString(uintptr_t value){require(word(value+4)==4);auto str=word(value);auto n=word(str+12);require(n<512);auto b=read(str+16,n);return std::string(b.begin(),b.end());}
static bool ownRequest(void* state,const char* symbol){try{auto base=word((uintptr_t)state+12);require(word((uintptr_t)state+8)>=base+16);return luaString(base)==".\\KOF13RecordingSlots.dll"&&luaString(base+8)==symbol;}catch(...){return false;}}
static void pushBridge(void* state,void* callback){uintptr_t fn=image()+0x17e630;
 __asm {
 mov ecx,state
 mov edx,callback
 push 0
 call fn
 add esp,4
 }
}
static int __cdecl restrictedLoadlib(void* state){if(ownRequest(state,"KOFReversalBridge")){pushBridge(state,(void*)&KOFReversalBridge);return 1;}if(ownRequest(state,"KOFCounterBridge")){pushBridge(state,(void*)&KOFCounterBridge);return 1;}if(ownRequest(state,"KOFRecordingBridge")){pushBridge(state,(void*)&KOFRecordingBridge);return 1;}if(ownRequest(state,"KOFHitboxBridge")){pushBridge(state,(void*)&KOFHitboxBridge);return 1;}if(ownRequest(state,"KOFVisibilityBridge")){pushBridge(state,(void*)&KOFVisibilityBridge);return 1;}if(ownRequest(state,"KOFSetupBridge")){pushBridge(state,(void*)&KOFSetupBridge);return 1;}return originalLoadlib(state);}
extern "C" __declspec(dllexport) int __cdecl InstallRecordingBridge(){try{verifyBuild();auto address=image()+0x18cc50;const Bytes expected{0x55,0x8b,0xec,0x51,0x56};if(originalLoadlib)return 1;require(read(address,5)==expected);auto trampoline=(unsigned char*)VirtualAlloc(nullptr,10,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);require(trampoline!=nullptr);memcpy(trampoline,expected.data(),5);trampoline[5]=0xe9;*(uint32_t*)(trampoline+6)=(uint32_t)(address+5-(uintptr_t)(trampoline+10));DWORD old;require(VirtualProtect(trampoline,10,PAGE_EXECUTE_READ,&old)!=0);FlushInstructionCache(GetCurrentProcess(),trampoline,10);unsigned char patch[5]={0xe9};*(uint32_t*)(patch+1)=(uint32_t)((uintptr_t)&restrictedLoadlib-address-5);if(!VirtualProtect((void*)address,5,PAGE_EXECUTE_READWRITE,&old)){VirtualFree(trampoline,0,MEM_RELEASE);throw Failure{-9};}originalLoadlib=(int(__cdecl*)(void*))trampoline;memcpy((void*)address,patch,5);DWORD unused;VirtualProtect((void*)address,5,old,&unused);FlushInstructionCache(GetCurrentProcess(),(void*)address,5);return 1;}catch(...){return 0;}}
