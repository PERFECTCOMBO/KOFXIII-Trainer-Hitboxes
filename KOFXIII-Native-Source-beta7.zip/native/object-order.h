// Test87: native loader owns object creation/data. Restore only captured sibling order afterwards.
struct OrderKey87 {bool marker=false;Bytes identity;bool operator==(const OrderKey87& b)const{return marker==b.marker&&identity==b.identity;}};
struct OrderNode87 {uintptr_t node=0;OrderKey87 key;};
struct OrderRing87 {uintptr_t head=0;std::vector<OrderNode87> nodes;};
using OrderSaved87=std::array<std::vector<OrderKey87>,2>;
static std::array<OrderRing87,2> inspectOrder87(){
 auto base=image();std::array<OrderRing87,2> rings;
 require(word(base+0x9b0684)==0,-14);
 for(int side=0;side<2;side++){
  auto actor=word(base+0x9b6fe8+side*4),core=word(word(actor+0x30)+8);require(word(core)==base+0x4ae8bc,-14);
  auto body=word(core+8);auto& ring=rings[side];ring.head=body+4;uintptr_t prior=ring.head,node=word(ring.head);std::set<uintptr_t> seen;
  while(node!=ring.head){
   require(ring.nodes.size()<32&&node>=0x10004&&seen.insert(node).second,-14);require(word(node+4)==prior,-14);
   auto obj=node-4,kind=word(obj);OrderKey87 key;
   if(kind==base+0x4afc90){require(ring.nodes.empty(),-14);key.marker=true;}
   else {
    require(kind==base+0x4ad24c,-14);auto hook=word(obj+0x50);require(hook&&word(hook)==base+0x4be78c,-14);
    auto controller=word(hook+0x10);require(controller&&word(controller)==base+0x4be740,-14);
    key.identity=read(obj+0x1f0,32); // native serialized object and parent UUIDs, not allocation addresses
    for(auto& n:ring.nodes)require(!(key==n.key),-14);
   }
   ring.nodes.push_back({node,key});prior=node;node=word(node);
  }
  require(word(ring.head+4)==prior,-14);require(!ring.nodes.empty()&&ring.nodes[0].key.marker,-14);
 }
 return rings;
}
static OrderSaved87 saveOrder87(){auto rings=inspectOrder87();OrderSaved87 saved;for(int side=0;side<2;side++)for(auto& n:rings[side].nodes)saved[side].push_back(n.key);return saved;}
struct OrderWrite87 {uintptr_t address;uint32_t before,after;};
static std::vector<OrderWrite87> planOrder87(const std::array<OrderRing87,2>& rings,const OrderSaved87& saved){
 std::vector<OrderWrite87> plan;std::set<uintptr_t> addresses;
 for(int side=0;side<2;side++){
  const auto& ring=rings[side];require(saved[side].size()==ring.nodes.size(),-14);std::vector<uintptr_t> order{ring.head};std::set<uintptr_t> used;
  for(auto& key:saved[side]){uintptr_t found=0;for(auto& n:ring.nodes)if(n.key==key){require(!found,-14);found=n.node;}require(found&&used.insert(found).second,-14);order.push_back(found);}
  for(size_t i=0;i<order.size();i++){
   uint32_t next=(uint32_t)order[(i+1)%order.size()],prev=(uint32_t)order[(i+order.size()-1)%order.size()];
   for(int j=0;j<2;j++){auto a=order[i]+j*4;require(addresses.insert(a).second,-14);valid(a,4,true);auto old=word(a),value=j?prev:next;plan.push_back({a,old,value});}
  }
 }
 return plan;
}
static void applyOrder87(const std::vector<OrderWrite87>& plan){
 // Validate every location before any write. Called only inside the paused menu callback after native load returns.
 for(auto& w:plan){valid(w.address,4,true);require(word(w.address)==w.before,-14);}
 for(auto& w:plan)memcpy((void*)w.address,&w.after,4);
}
static void restoreOrder87(const OrderSaved87& saved){auto plan=planOrder87(inspectOrder87(),saved);applyOrder87(plan);require(saveOrder87()==saved,-14);}
