// Native code owns allocation and payload. This supplement owns only ordered
// membership of the independent +0x1c child heads / +0x0c member links.
struct ParentRing103 {Bytes owner; uintptr_t head; std::vector<OrderNode87> nodes;};
struct ParentSaved103 {Bytes owner; std::vector<OrderKey87> keys;
 bool operator==(const ParentSaved103& b)const{return owner==b.owner&&keys==b.keys;}};
using ParentSnapshot103=std::vector<ParentSaved103>;
static std::vector<ParentRing103> inspectParents103(){
 auto siblings=inspectOrder87();std::vector<ParentRing103> rings;
 std::vector<OrderNode87> members;std::set<Bytes> identities;
 for(int side=0;side<2;side++){
  rings.push_back({Bytes{0,(unsigned char)side},siblings[side].head-4+0x1c,{}});
  for(auto& n:siblings[side].nodes)if(!n.key.marker){
   require(n.key.identity.size()==32&&identities.insert(Bytes(n.key.identity.begin(),n.key.identity.begin()+16)).second,-14);
   members.push_back({n.node-4+0xc,n.key});
  }
 }
 for(auto& n:members){Bytes owner{1};owner.insert(owner.end(),n.key.identity.begin(),n.key.identity.begin()+16);rings.push_back({owner,n.node-0xc+0x1c,{}});}
 std::set<uintptr_t> heads,seen;
 for(auto& r:rings)require(heads.insert(r.head).second,-14);
 for(auto& r:rings){uintptr_t prev=r.head,node=word(r.head);
  while(node!=r.head){
   require(r.nodes.size()<64&&seen.insert(node).second&&!heads.count(node),-14);
   const OrderNode87* found=nullptr;for(auto& n:members)if(n.node==node){require(!found,-14);found=&n;}
   require(found&&word(node+4)==prev,-14);
   if(r.owner[0]==1)require(Bytes(found->key.identity.begin()+16,found->key.identity.end())==Bytes(r.owner.begin()+1,r.owner.end()),-14);
   r.nodes.push_back(*found);prev=node;node=word(node);
  }
  require(word(r.head+4)==prev,-14);
 }
 require(seen.size()==members.size(),-14);
 // Reject ownership cycles, including self-parenting. Every object must reach a fighter.
 for(auto& member:members){auto key=member.key;std::set<Bytes> ancestry;
  for(;;){Bytes id(key.identity.begin(),key.identity.begin()+16);require(ancestry.insert(id).second,-14);
   const ParentRing103* owner=nullptr;for(auto& r:rings)for(auto& n:r.nodes)if(n.key==key){require(!owner,-14);owner=&r;}
   require(owner,-14);if(owner->owner[0]==0)break;
   bool found=false;for(auto& n:members)if(Bytes(n.key.identity.begin(),n.key.identity.begin()+16)==Bytes(owner->owner.begin()+1,owner->owner.end())){key=n.key;found=true;break;}require(found,-14);
  }
 }
 return rings;
}
static ParentSnapshot103 snapshotParents103(const std::vector<ParentRing103>& rings){ParentSnapshot103 out;for(auto& r:rings){ParentSaved103 s;s.owner=r.owner;for(auto& n:r.nodes)s.keys.push_back(n.key);out.push_back(s);}return out;}
static ParentSnapshot103 saveParents103(){return snapshotParents103(inspectParents103());}
static std::vector<OrderWrite87> planParents103(const std::vector<ParentRing103>& rings,const ParentSnapshot103& saved){
 require(rings.size()==saved.size(),-14);std::set<Bytes> owners,usedOwners;std::set<uintptr_t> addresses;std::vector<OrderWrite87> plan;
 for(auto& r:rings)require(owners.insert(r.owner).second,-14);
 for(auto& s:saved){require(usedOwners.insert(s.owner).second,-14);const ParentRing103* ring=nullptr;for(auto& r:rings)if(r.owner==s.owner)ring=&r;require(ring&&ring->nodes.size()==s.keys.size(),-14);
  std::vector<uintptr_t> order{ring->head};std::set<uintptr_t> used;
  for(auto& k:s.keys){require(!k.marker&&k.identity.size()==32,-14);uintptr_t node=0;for(auto& n:ring->nodes)if(n.key==k){require(!node,-14);node=n.node;}require(node&&used.insert(node).second,-14);order.push_back(node);}
  for(size_t i=0;i<order.size();i++)for(size_t j=0;j<2;j++){auto a=order[i]+4*j;require(addresses.insert(a).second,-14);valid(a,4,true);plan.push_back({a,word(a),(uint32_t)order[(i+(j?order.size()-1:1))%order.size()]});}
 }
 return plan;
}
static void restoreLists103(const OrderSaved87& siblings,const ParentSnapshot103& parents){
 // Plan BOTH lists before any supplemental write, then validate every old word.
 auto plan=planOrder87(inspectOrder87(),siblings);auto childPlan=planParents103(inspectParents103(),parents);
 plan.insert(plan.end(),childPlan.begin(),childPlan.end());std::set<uintptr_t> addresses;for(auto& w:plan)require(addresses.insert(w.address).second,-14);
 applyOrder87(plan);
 try{require(saveOrder87()==siblings,-14);auto current=saveParents103();require(current.size()==parents.size(),-14);for(auto& s:parents){bool found=false;for(auto& c:current)if(c==s)found=true;require(found,-14);}}
 catch(...){for(auto& w:plan)memcpy((void*)w.address,&w.before,4);throw;}
}
