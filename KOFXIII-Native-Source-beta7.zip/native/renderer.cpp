#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d9.h>
#include <wincrypt.h>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <algorithm>
#pragma comment(lib,"advapi32.lib")

// SNK collision renderer port: original draw-loop instructions, original shaders,
// original unit geometry/palette; adapters replace engine/container/CRT boundaries.
static uintptr_t base;
static HMODULE systemD3D;
static INIT_ONCE once=INIT_ONCE_STATIC_INIT;
static SRWLOCK frameLock=SRWLOCK_INIT;
struct Box { float left,bottom,width,height; unsigned group; };
struct Frame { Box boxes[256]; unsigned count; float matrix[16]; DWORD tick; };
static Frame latest;
// Reference colors for the three verified categories; preserve the other groups.
static const float displayPalette[6][4]={{0,1,0,4},{1,0,0,4},{0,1,0,2},{0,0,1,2},{1,0,1,2},{1,1,1,2}};
#include "../snk-renderer/original-adapter.h"
#include "../snk-renderer/original-shaders.h"
static IDirect3DDevice9* shaderDevice;
static IDirect3DVertexShader9* collisionVS;
static IDirect3DPixelShader9* collisionPS;
static IDirect3DVertexDeclaration9* collisionDeclaration;
static bool shaders(IDirect3DDevice9* device){
 if(shaderDevice==device&&collisionVS&&collisionPS&&collisionDeclaration)return true;
 if(collisionVS)collisionVS->Release();if(collisionPS)collisionPS->Release();if(collisionDeclaration)collisionDeclaration->Release();if(shaderDevice)shaderDevice->Release();
 collisionVS=nullptr;collisionPS=nullptr;collisionDeclaration=nullptr;shaderDevice=device;device->AddRef();
 const D3DVERTEXELEMENT9 elements[]={{0,0,D3DDECLTYPE_FLOAT4,D3DDECLMETHOD_DEFAULT,D3DDECLUSAGE_POSITION,0},D3DDECL_END()};
 return SUCCEEDED(device->CreateVertexShader(snkVertexShader,&collisionVS))&&SUCCEEDED(device->CreatePixelShader(snkPixelShader,&collisionPS))&&SUCCEEDED(device->CreateVertexDeclaration(elements,&collisionDeclaration));
}
static volatile LONG* controls;
static HANDLE controlMap;
static unsigned draws;
static bool supported;
static void log(const char* s){wchar_t p[MAX_PATH];GetModuleFileNameW(nullptr,p,MAX_PATH);wchar_t* end=wcsrchr(p,L'\\');if(!end)return;wcscpy_s(end,MAX_PATH-(end-p),L"\\native-hitboxes.log");FILE* f=nullptr;_wfopen_s(&f,p,L"a");if(f){fprintf(f,"%s\n",s);fclose(f);}}
static bool fingerprint(){
 wchar_t path[MAX_PATH];if(!GetModuleFileNameW(nullptr,path,MAX_PATH))return false;
 HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);if(f==INVALID_HANDLE_VALUE)return false;
 HCRYPTPROV p=0;HCRYPTHASH h=0;bool ok=CryptAcquireContextW(&p,nullptr,nullptr,PROV_RSA_AES,CRYPT_VERIFYCONTEXT)&&CryptCreateHash(p,CALG_SHA_256,0,0,&h);BYTE buf[65536],hash[32];DWORD n=0;
 while(ok){if(!ReadFile(f,buf,sizeof(buf),&n,nullptr)){ok=false;break;}if(!n)break;ok=!!CryptHashData(h,buf,n,0);}
 n=32;if(ok)ok=!!CryptGetHashParam(h,HP_HASHVAL,hash,&n,0);if(h)CryptDestroyHash(h);if(p)CryptReleaseContext(p,0);CloseHandle(f);
 const BYTE expected[]={0xe7,0x71,0x8f,0x5c,0x55,0x3d,0xe8,0x52,0x13,0x5d,0xde,0xf5,0x83,0x3a,0x7b,0xb6,0xea,0xfd,0x05,0x50,0x8d,0x12,0x06,0xac,0x6f,0x3c,0xe7,0x76,0x7b,0x47,0x48,0x35};
 return ok&&!memcmp(hash,expected,32);
}
static bool practice(){return *(DWORD*)(base+0x99a62c)==7&&*(DWORD*)(base+0x999178)==0;}
static bool collect(void* engine,Frame* f){
 __try {
  if(!practice())return false;
  uintptr_t e=(uintptr_t)engine;
  for(unsigned group=0;group<10;group++){
   uintptr_t head=*(uintptr_t*)(e+0x18+group*8),node=*(uintptr_t*)head;unsigned traversed=0;
   while(node!=head){
    if(++traversed>256||f->count>=256)return false;
    Box b;memcpy(&b,(void*)(node+0xc),16);b.group=group;
    if(!std::isfinite(b.left)||!std::isfinite(b.bottom)||!std::isfinite(b.width)||!std::isfinite(b.height))return false;
    if(b.width>0&&b.height>0&&b.width<100000&&b.height<100000)f->boxes[f->count++]=b;
    node=*(uintptr_t*)node;
   }
  }
  uintptr_t camera=*(uintptr_t*)(base+0x99a060);if(!camera)return false;
  memcpy(f->matrix,(void*)(camera+8),64);
  for(float v:f->matrix)if(!std::isfinite(v))return false;
  f->tick=GetTickCount();return true;
 }__except(EXCEPTION_EXECUTE_HANDLER){return false;}
}
static void __fastcall capture(void* engine,void*){
 Frame next={};bool ok=collect(engine,&next);static bool reported=false;if(ok&&!reported){reported=true;char msg[100];sprintf_s(msg,"Captured first Practice frame: %u boxes.",next.count);log(msg);}
 AcquireSRWLockExclusive(&frameLock);latest=ok?next:Frame{};ReleaseSRWLockExclusive(&frameLock);
 ((void(__thiscall*)(void*))(base+0x1d8ab0))(engine);
}
static HRESULT WINAPI gameEndScene(IDirect3DDevice9* d);
static bool installCapture(){
 auto captureSite=(BYTE*)(base+0x1d7551);auto drawSite=(BYTE*)(base+0x20f5ea);
 const BYTE captureExpected[]={0xe8,0x5a,0x15,0,0,0x8b,0xcb,0xe8,0xe3,0xfb,0xff,0xff};
 const BYTE drawExpected[]={0xff,0x91,0xa8,0,0,0};
 if(memcmp(captureSite,captureExpected,sizeof(captureExpected))||memcmp(drawSite,drawExpected,6)){log("Capture/render site conflict: no hooks installed.");return false;}
 DWORD oldCapture,oldDraw;
 if(!VirtualProtect(captureSite,5,PAGE_EXECUTE_READWRITE,&oldCapture))return false;
 if(!VirtualProtect(drawSite,6,PAGE_EXECUTE_READWRITE,&oldDraw)){DWORD ignored;VirtualProtect(captureSite,5,oldCapture,&ignored);return false;}
 captureSite[0]=0xe8;*(DWORD*)(captureSite+1)=(DWORD)((uintptr_t)&capture-(uintptr_t)(captureSite+5));
 drawSite[0]=0xe8;*(DWORD*)(drawSite+1)=(DWORD)((uintptr_t)&gameEndScene-(uintptr_t)(drawSite+5));drawSite[5]=0x90;
 DWORD ignored;VirtualProtect(captureSite,5,oldCapture,&ignored);VirtualProtect(drawSite,6,oldDraw,&ignored);
 FlushInstructionCache(GetCurrentProcess(),captureSite,5);FlushInstructionCache(GetCurrentProcess(),drawSite,6);
 log("Native capture and game scene-end hooks installed before gameplay.");return true;
}
static void initControls(){
 wchar_t name[96];swprintf_s(name,L"Local\\KOF13HitboxControl_%lu",GetCurrentProcessId());
 controlMap=CreateFileMappingW(INVALID_HANDLE_VALUE,nullptr,PAGE_READWRITE,0,32,name);if(!controlMap)return;
 bool fresh=GetLastError()!=ERROR_ALREADY_EXISTS;
 controls=(volatile LONG*)MapViewOfFile(controlMap,FILE_MAP_ALL_ACCESS,0,0,32);if(!controls)return;
 if(fresh){controls[1]=2;controls[2]=15;controls[3]=controls[4]=controls[5]=controls[6]=controls[7]=0;MemoryBarrier();controls[0]=0x48423130;}
 if(controls[0]!=0x48423130||controls[1]!=2)controls=nullptr;
}
static void draw(IDirect3DDevice9* d,bool inside=false){
 if(!supported)return;
 if(controls)InterlockedExchange(controls+6,(LONG)GetTickCount());
 LONG flags=controls?controls[2]:15;
 if(!(flags&1)||!practice())return;
 Frame f;AcquireSRWLockShared(&frameLock);f=latest;ReleaseSRWLockShared(&frameLock);
 if(!f.count||!shaders(d))return;
 IDirect3DSurface9 *back=nullptr,*oldRT=nullptr,*oldDepth=nullptr;IDirect3DStateBlock9* state=nullptr;
 if(FAILED(d->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&back)))return;
 if(inside){IDirect3DSurface9* rt=nullptr;d->GetRenderTarget(0,&rt);bool same=rt==back;if(rt)rt->Release();if(!same){back->Release();return;}}
 D3DSURFACE_DESC desc;back->GetDesc(&desc);
 if(FAILED(d->CreateStateBlock(D3DSBT_ALL,&state))){back->Release();return;}
 d->GetRenderTarget(0,&oldRT);d->GetDepthStencilSurface(&oldDepth);
 D3DVIEWPORT9 oldVP;d->GetViewport(&oldVP);
 d->SetRenderTarget(0,back);d->SetDepthStencilSurface(nullptr);
 D3DVIEWPORT9 vp={0,0,desc.Width,desc.Height,0,1};d->SetViewport(&vp);
 HRESULT begin=inside?S_OK:d->BeginScene();
 if(SUCCEEDED(begin)){
  d->SetVertexShader(collisionVS);d->SetPixelShader(collisionPS);d->SetVertexDeclaration(collisionDeclaration);d->SetTexture(0,nullptr);
  float projection[16];memcpy(projection,f.matrix,64);
  // Steam's fighter render layer is enlarged by RTCopyNode before the final backbuffer.
  // Adapt only that host transform; SNK's original shader and draw loop are unchanged.
  for(int row=0;row<4;row++){projection[row*4]*=1.125f;projection[row*4+1]*=1.125f;}
  d->SetVertexShaderConstantF(0,projection,4);
  d->SetRenderState(D3DRS_ZENABLE,FALSE);d->SetRenderState(D3DRS_ZWRITEENABLE,FALSE);d->SetRenderState(D3DRS_STENCILENABLE,FALSE);d->SetRenderState(D3DRS_ALPHATESTENABLE,FALSE);
  d->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);d->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);d->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);d->SetRenderState(D3DRS_BLENDOP,D3DBLENDOP_ADD);
  d->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);d->SetRenderState(D3DRS_LIGHTING,FALSE);d->SetRenderState(D3DRS_FOGENABLE,FALSE);d->SetRenderState(D3DRS_SCISSORTESTENABLE,FALSE);d->SetRenderState(D3DRS_COLORWRITEENABLE,15);d->SetRenderState(D3DRS_SRGBWRITEENABLE,FALSE);
  d->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_SELECTARG1);d->SetTextureStageState(0,D3DTSS_COLORARG1,D3DTA_DIFFUSE);d->SetTextureStageState(0,D3DTSS_ALPHAOP,D3DTOP_SELECTARG1);d->SetTextureStageState(0,D3DTSS_ALPHAARG1,D3DTA_DIFFUSE);d->SetTextureStageState(1,D3DTSS_COLOROP,D3DTOP_DISABLE);
  Frame selected={};
  for(unsigned i=0;i<f.count;i++){auto box=f.boxes[i];unsigned kind=box.group%5;bool show=kind==0?(flags&8):kind==1?(flags&2):kind==3?(flags&4):true;if(show){box.group=kind;selected.boxes[selected.count++]=box;}}
  unsigned fill=(flags>>4)&3;
  if(fill){
   // Original vertex shader: zero border offsets give a solid unit rectangle.
   // Constant blending supplies opacity without altering SNK's shader bytecode.
   const float quad[4][4]={{0,0,0,0},{1,0,0,0},{0,1,0,0},{1,1,0,0}};
   float opacity=fill==1?40.0f/255.0f:80.0f/255.0f;
   d->SetRenderState(D3DRS_BLENDFACTOR,D3DCOLOR_COLORVALUE(opacity,opacity,opacity,opacity));
   d->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_BLENDFACTOR);d->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVBLENDFACTOR);
   for(unsigned i=0;i<selected.count;i++){
    const auto& box=selected.boxes[i];
    d->SetVertexShaderConstantF(4,displayPalette[box.group],1);
    d->SetVertexShaderConstantF(5,&box.left,1);
    d->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP,2,quad,sizeof(quad[0]));
   }
   d->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);d->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
  }
  OriginalEntity entity={};entity.frame=&selected;OriginalDevice context={};context.device=d;snkLoop(&entity,&context);
  if(!inside)d->EndScene();if(!draws++){char msg[160];sprintf_s(msg,"First original SNK draw-loop + shader frame: %u boxes, backbuffer %ux%u; no viewer process.",f.count,desc.Width,desc.Height);log(msg);}
 }
 if(FAILED(begin)){static bool reported=false;if(!reported){reported=true;char msg[100];sprintf_s(msg,"Present BeginScene refused: %08lx; trying EndScene hook.",begin);log(msg);}}
 d->SetRenderTarget(0,oldRT);d->SetDepthStencilSurface(oldDepth);state->Apply();d->SetViewport(&oldVP);
 if(oldDepth)oldDepth->Release();if(oldRT)oldRT->Release();state->Release();back->Release();
}
static HRESULT WINAPI gameEndScene(IDirect3DDevice9* d){draw(d,true);return d->EndScene();}
static BOOL CALLBACK initialize(PINIT_ONCE,PVOID,PVOID*){

 wchar_t dir[MAX_PATH];GetSystemDirectoryW(dir,MAX_PATH);wcscat_s(dir,L"\\d3d9.dll");systemD3D=LoadLibraryW(dir);base=(uintptr_t)GetModuleHandleW(nullptr);
 supported=fingerprint();if(supported){supported=prepareOriginalLoop(displayPalette)&&installCapture();if(supported)initControls();}log(supported?"Native hitboxes initialized: reference RGB palette, OFF/LIGHT/STRONG fill enabled.":"Unsupported build or hook conflict: renderer disabled.");return TRUE;
}
extern "C" __declspec(dllexport) int __cdecl InitializeHitboxes(){
 InitOnceExecuteOnce(&once,initialize,nullptr,nullptr);return supported?1:0;
}
extern "C" IDirect3D9* WINAPI ProxyDirect3DCreate9(UINT sdk){
 InitOnceExecuteOnce(&once,initialize,nullptr,nullptr);if(!systemD3D)return nullptr;
 auto fn=(IDirect3D9*(WINAPI*)(UINT))GetProcAddress(systemD3D,"Direct3DCreate9");auto obj=fn?fn(sdk):nullptr;

 return obj;
}
BOOL WINAPI DllMain(HINSTANCE,DWORD,LPVOID){return TRUE;}

static FARPROC forwarded[23];
static void __cdecl resolveForward(unsigned i){InitOnceExecuteOnce(&once,initialize,nullptr,nullptr);forwarded[i]=GetProcAddress(systemD3D,MAKEINTRESOURCEA(i+16));}
extern "C" __declspec(naked) void Forward16(){__asm{pushfd
 pushad
 push 0
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+0]
}}
extern "C" __declspec(naked) void Forward17(){__asm{pushfd
 pushad
 push 1
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+4]
}}
extern "C" __declspec(naked) void Forward18(){__asm{pushfd
 pushad
 push 2
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+8]
}}
extern "C" __declspec(naked) void Forward19(){__asm{pushfd
 pushad
 push 3
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+12]
}}
extern "C" __declspec(naked) void Forward20(){__asm{pushfd
 pushad
 push 4
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+16]
}}
extern "C" __declspec(naked) void Forward21(){__asm{pushfd
 pushad
 push 5
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+20]
}}
extern "C" __declspec(naked) void Forward22(){__asm{pushfd
 pushad
 push 6
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+24]
}}
extern "C" __declspec(naked) void Forward23(){__asm{pushfd
 pushad
 push 7
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+28]
}}
extern "C" __declspec(naked) void Forward24(){__asm{pushfd
 pushad
 push 8
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+32]
}}
extern "C" __declspec(naked) void Forward25(){__asm{pushfd
 pushad
 push 9
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+36]
}}
extern "C" __declspec(naked) void Forward26(){__asm{pushfd
 pushad
 push 10
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+40]
}}
extern "C" __declspec(naked) void Forward27(){__asm{pushfd
 pushad
 push 11
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+44]
}}
extern "C" __declspec(naked) void Forward28(){__asm{pushfd
 pushad
 push 12
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+48]
}}
extern "C" __declspec(naked) void Forward29(){__asm{pushfd
 pushad
 push 13
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+52]
}}
extern "C" __declspec(naked) void Forward30(){__asm{pushfd
 pushad
 push 14
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+56]
}}
extern "C" __declspec(naked) void Forward31(){__asm{pushfd
 pushad
 push 15
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+60]
}}
extern "C" __declspec(naked) void Forward32(){__asm{pushfd
 pushad
 push 16
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+64]
}}
extern "C" __declspec(naked) void Forward33(){__asm{pushfd
 pushad
 push 17
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+68]
}}
extern "C" __declspec(naked) void Forward34(){__asm{pushfd
 pushad
 push 18
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+72]
}}
extern "C" __declspec(naked) void Forward35(){__asm{pushfd
 pushad
 push 19
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+76]
}}
extern "C" __declspec(naked) void Forward36(){__asm{pushfd
 pushad
 push 20
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+80]
}}
extern "C" __declspec(naked) void Forward38(){__asm{pushfd
 pushad
 push 22
 call resolveForward
 add esp,4
 popad
 popfd
 jmp dword ptr [forwarded+88]
}}
