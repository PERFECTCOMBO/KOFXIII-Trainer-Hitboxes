// Build replacement deques using the supported game's allocator, before touching
// either live header. Keep each actor's opaque first word/proxy unchanged.
struct RecordDeque116 { uint32_t opaque=0,map=0,size=0,offset=0,count=0; };
static_assert(sizeof(RecordDeque116)==20,"deque ABI");
#ifndef SLOTS_TEST
static void pushRecord116(RecordDeque116* q,const unsigned char* entry){
 auto fn=(void(__thiscall*)(void*,const void*))(image()+0x15a690);fn(q,entry);
}
static void clearRecord116(RecordDeque116* q){
 auto fn=(void(__thiscall*)(void*))(image()+0x9e250);fn(q);
}
#else
static void (*pushRecord116)(RecordDeque116*,const unsigned char*);
static void (*clearRecord116)(RecordDeque116*);
#endif
static void replaceRecord116(const std::array<Stream,2>& saved){
 verifyBuild();guard();
 auto actors=read(image()+0x9b6fe8,8);uintptr_t headers[2];Bytes old[2];std::set<uintptr_t> allocations;
 for(int p=0;p<2;p++){
  headers[p]=word(image()+0x9b6fe8+p*4)+0x1d4;
  valid(headers[p],20,true);old[p]=read(headers[p],20);
#ifndef SLOTS_TEST
  auto map=word(headers[p]+4),size=word(headers[p]+8),count=word(headers[p]+16);
  require(count<=36000);
  if(map){require(size>=8&&size<=65536&&!(size&(size-1))&&count<=size*2);valid(map,size*4);require(allocations.insert(map).second);for(uint32_t i=0;i<size;i++){auto block=word(map+i*4);if(block){valid(block,16,true);require(allocations.insert(block).second);}}}
  else require(size==0&&count==0);
#endif
  require(saved[p].entries.size()%5==0&&saved[p].entries.size()<=180000,-5);
 }
 require(headers[0]!=headers[1]);
 RecordDeque116 temp[2];
 try{
  for(int p=0;p<2;p++)for(size_t i=0;i<saved[p].entries.size();i+=5){
   unsigned char entry[8]{};memcpy(entry,saved[p].entries.data()+i,5);require(entry[4]<=1,-5);pushRecord116(&temp[p],entry);
  }
  guard();require(read(image()+0x9b6fe8,8)==actors);
  for(int p=0;p<2;p++)require(read(headers[p],20)==old[p]);
  // Nonthrowing commit: both allocations completed; original buffers stay owned
  // by temp until both live headers have been replaced on this game thread.
  for(int p=0;p<2;p++){
   unsigned char oldStorage[16];memcpy(oldStorage,(void*)(headers[p]+4),16);
   memcpy((void*)(headers[p]+4),((unsigned char*)&temp[p])+4,16);
   memcpy(((unsigned char*)&temp[p])+4,oldStorage,16);
  }
 }catch(...){for(auto& q:temp)clearRecord116(&q);throw;}
 for(auto& q:temp)clearRecord116(&q);
}
static std::vector<int> eligible116(const std::array<std::array<Stream,2>,5>& bank,int){
 std::vector<int> ids;for(int i=0;i<5;i++)if(!bank[i][1].entries.empty())ids.push_back(i);
 // Independent draws include the previous slot. Excluding it forces alternation
 // when only two recordings exist.
 return ids;
}
static int chooseRandom116(const std::vector<int>& ids,uint32_t draw){
 require(!ids.empty(),-3);
 return ids[draw%ids.size()];
}
static int randomRecord116(int action,int selected){
 verifyBuild();guard();std::array<std::array<Stream,2>,5> bank;
 auto folder=directory()+L"\\KOF13RecordingSlots\\standard-";
 if(action==4){bank[selected-1]=decode(fileRead(folder+std::to_wstring(selected)+L".k13rec",361024));require(!bank[selected-1][1].entries.empty(),-3);replaceRecord116(bank[selected-1]);return 20+selected;}
 for(int i=0;i<5;i++){
  auto path=folder+std::to_wstring(i+1)+L".k13rec";
  if(GetFileAttributesW(path.c_str())==INVALID_FILE_ATTRIBUTES)continue;
  // Invalid archives fail closed; they are not silently classified as empty.
  bank[i]=decode(fileRead(path,361024));
 }
 auto ids=eligible116(bank,0);require(!ids.empty(),-3);
 HCRYPTPROV prov=0;require(CryptAcquireContextW(&prov,0,0,PROV_RSA_AES,CRYPT_VERIFYCONTEXT)!=0);
 uint32_t draw=0;bool ok=CryptGenRandom(prov,4,(BYTE*)&draw)!=0;CryptReleaseContext(prov,0);require(ok);
 int chosen=chooseRandom116(ids,draw);replaceRecord116(bank[chosen]);
#ifndef SLOTS_TEST
 std::ofstream log(directory()+L"\\KOF13RecordingSlots\\random-playback116.log",std::ios::app);log<<"slot="<<chosen+1<<" p1="<<bank[chosen][0].entries.size()/5<<" p2="<<bank[chosen][1].entries.size()/5<<" thread="<<GetCurrentThreadId()<<" tick="<<GetTickCount64()<<"\n";
#endif
 return 21+chosen;
}
