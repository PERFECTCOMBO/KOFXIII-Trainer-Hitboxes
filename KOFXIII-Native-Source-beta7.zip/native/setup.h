#include "state-probe.h"
#include "state-load.h"
#include <cmath>
// Test 68 experimental plain-air support; Test 67: reacquire render/physics objects rebuilt by TrainingModeReStart.
// Audited against ResetTrainingGauge (555a00), position (448000/448040),
// facing (447fa0/447fc0). No animation/object heaps or projectile data copied.
// Only scalar fields: never copy body pointers, linked lists or script objects.
struct Air68 {bool active=false;std::array<uint32_t,8> animation{};std::array<float,3> speed{};uint32_t movement=0;};
struct SetupFighter66 {Air68 air;uintptr_t actor,core,body;uint32_t identityA,identityB;float x,y,z,facing;uint32_t health,stocks;float guard,stun,drive,power;};
static std::array<SetupFighter66,2> savedSetup66{};
static bool hasSetup66=false;
static bool loadArmed67=false;
static DWORD loadTick67=0;
static float scalar66(uintptr_t p){auto b=read(p,4);float f;memcpy(&f,b.data(),4);require(std::isfinite(f),-14);return f;}
static void bounded66(float f,float lo,float hi){require(std::isfinite(f)&&f>=lo&&f<=hi,-14);}
static void inspectAir68(SetupFighter66& f,bool nativeArchive=false){
 require(f.identityA==3&&f.identityB==0,-13);
#ifndef SLOTS_TEST
 static bool checked=false;if(!checked){auto d=digest(fileRead(directory()+L"\\fighter\\03.lua",16*1024*1024));std::string hex;for(auto v:d){hex+="0123456789ABCDEF"[v>>4];hex+="0123456789ABCDEF"[v&15];}require(hex=="A09A81FB72FBE7105B76D9E2096FC4447011B1A05E3ADA30C0D6F49775889914",-8);checked=true;}
#endif
 struct Spec {uint32_t action,state,count,x,y;};
 static const Spec specs[]={{10,24,9,32769,32772},{12,19,14,32769,32773},{13,25,9,32774,32772},{15,21,14,32774,32773},{17,30,14,32775,32773},{18,26,9,32776,32772},{20,23,14,32777,32773},{22,32,14,32778,32773},{23,27,12,32775,32772},{24,28,12,32778,32772}};
 auto& a=f.air;for(size_t j=0;j<a.animation.size();j++)a.animation[j]=word(f.body+0x88+j*4);
 const Spec* spec=nullptr;for(auto& v:specs)if(v.action==a.animation[0])spec=&v;require(spec!=nullptr,-13);
 require(a.animation[6]==spec->state&&a.animation[7]==spec->state&&a.animation[2]==spec->count,-13);
 require(a.animation[1]>=1&&a.animation[1]<spec->count&&a.animation[3]<=3&&a.animation[4]==0&&a.animation[5]>=1&&a.animation[5]<=120,-13);
 a.movement=word(f.body+0x1a0);require(a.movement==(spec->x|(spec->y<<16)),-13);
 bounded66(f.y,0.01f,200);require(std::abs(f.z)<0.01f,-13);
 for(int j=0;j<3;j++)a.speed[j]=scalar66(f.body+0x128+j*4);
 bounded66(a.speed[0],-12,12);bounded66(a.speed[1],-18,27);require(a.speed[2]==0,-13);
 require(scalar66(f.body+0x138)==1&&scalar66(f.body+0x13c)==1,-13);
 for(auto off:{0x98,0x114,0x1b4,0x1b8,0x1bc,0x1c0,0x1c4})require(word(f.body+off)==0,-13);
 auto flags=read(f.body+0x1e4,2);
 // Both values observed in plain jumps; native serializer preserves bit 15.
 // Scalar setup restore keeps its original exact flag requirement.
 require(read(f.body+0xb4,2)==Bytes({0,0})&&(flags==Bytes({0,132})||(nativeArchive&&flags==Bytes({0,4}))),-13);
 a.active=true;
}
static std::array<SetupFighter66,2> inspectSetup66(bool nativeArchive=false){
 verifyBuild();guard();std::array<SetupFighter66,2> out{};
 for(int i=0;i<2;i++){auto& f=out[i];f.actor=word(image()+0x9b6fe8+i*4);auto wrapper=word(f.actor+0x30);f.core=word(wrapper+8);require(word(f.core)==image()+0x4ae8bc,-8);f.body=word(f.core+8);
 // These two actor identity fields are preserved by native restart (59ea07/59ea0d).
 f.identityA=word(f.actor+0x20);f.identityB=word(f.actor+0x24);
 f.x=scalar66(f.body+0x11c);f.y=scalar66(f.body+0x120);f.z=scalar66(f.body+0x124);f.facing=scalar66(f.body+0x134);
 bounded66(f.x,-2000,2000);if(std::abs(f.y)>=0.01f)inspectAir68(f,nativeArchive);else require(std::abs(f.z)<0.01f,-13);require(f.facing==1||f.facing==-1,-14);
 f.health=word(f.actor+0x48);require(f.health>0&&f.health<=word(f.actor+0x4c),-14);
 f.guard=scalar66(f.actor+0x64);bounded66(f.guard,0,(float)word(f.actor+0x60));
 f.stun=scalar66(f.actor+0x8c);bounded66(f.stun,0,(float)word(f.actor+0x88));
 f.drive=scalar66(f.actor+0xc0);bounded66(f.drive,0,scalar66(f.actor+0xbc));
 f.power=scalar66(f.actor+0xd0);bounded66(f.power,0,1000);
 f.stocks=word(f.actor+0xd4);require(f.stocks<=word(f.actor+0xd8),-14);
 }require(out[0].actor!=out[1].actor&&out[0].core!=out[1].core&&out[0].body!=out[1].body);return out;
}
// Test77 experimental standing Kyo LP admission, native archive only.
// Observed action68/state45. No scalar restore path uses this predicate.
static bool plainPunch77(const SetupFighter66& f){
 if(f.identityA!=3||f.identityB!=0||std::abs(f.y)>=0.01f||std::abs(f.z)>=0.01f)return false;
 auto b=f.body;auto frame=word(b+0x8c);
 return word(b+0x88)==68&&frame>=1&&frame<10&&word(b+0x90)==10&&word(b+0x94)<=2&&word(b+0x98)==0&&word(b+0xa0)==45&&(word(b+0xa4)==45||word(b+0xa4)==1)&&word(b+0x1a0)==2147581953u&&word(b+0x1b8)==0&&(read(b+0x1e4,2)==Bytes({0,132})||read(b+0x1e4,2)==Bytes({0,4}));
}
// Test79: observed Kyo close HP / standing Ryo reaction, native archive only.
static bool observedHit79(const SetupFighter66& f){
 if(f.identityB!=0||std::abs(f.y)>=0.01f||std::abs(f.z)>=0.01f)return false;
 auto b=f.body;auto flags=word(b+0x1e4)&0xffff;auto frame=word(b+0x8c);auto state2=word(b+0xa4);
 if(flags!=0x400&&flags!=0x40c&&flags!=0x8400&&flags!=0x840c)return false;
 // Test80: live capture 20261015-201043 observed body1b8=1 with hit-freeze bit8.
 if(word(b+0x98)!=0)return false;
 auto freezeField=word(b+0x1b8);if(freezeField!=0&&!(freezeField==1&&(flags&8)))return false;
 if(f.identityA==3)return word(b+0x88)==76&&word(b+0x90)==13&&frame>=1&&frame<=13&&word(b+0x94)<=2&&word(b+0xa0)==47&&(state2==47||state2==1)&&(word(b+0x1a0)==2147581953u||(word(b+0x1a0)>=2147581982u&&word(b+0x1a0)<=2147581986u));
 if(f.identityA==18)return word(b+0x88)==133&&word(b+0x90)==7&&frame>=1&&frame<=7&&word(b+0x94)<=6&&word(b+0xa0)==110&&(state2==110||state2==1)&&word(b+0x1a0)==2147581953u;
 return false;
}
// Test81: observed Ryo HP projectile startup/recovery, native archive only.
static bool observedRyo81(const SetupFighter66& f){
 if(f.identityA!=18||f.identityB!=0||f.y!=0||f.z!=0)return false;
 auto b=f.body;auto frame=word(b+0x8c);auto flags=word(b+0x1e4)&0xffff;
 return word(b+0x88)==452&&word(b+0x90)==30&&frame>=2&&frame<=30&&word(b+0x94)<=4&&word(b+0x98)==0&&word(b+0xa0)==171&&(word(b+0xa4)==171||word(b+0xa4)==1)&&word(b+0x1b8)==0&&(flags==0x400||flags==0x8400)&&(word(b+0x1a0)==2147581953u||word(b+0x1a0)==2147582227u);
}
// Test89 experimental exact defender tuple observed in two independent projectile contacts.
// No state reconstruction; this only admits native capture/load for this measured snapshot.
static bool observedRyoHit89(const SetupFighter66& f){
 if(f.identityA!=18||f.identityB!=1||f.y!=0||f.z!=0)return false;
 const uint32_t animation[]={171,2,9,0,0,1,126,126};
 for(int i=0;i<8;i++)if(word(f.body+0x88+4*i)!=animation[i])return false;
 return word(f.body+0x1a0)==2153087060u&&word(f.body+0x1b8)==1&&(word(f.body+0x1e4)&0xffff)==0x40c;
}
// Native archive admission only: no scalar setup restoration is used here.
// Airborne cases retain the observed Kyo plain-jump whitelist from Test68.
static std::array<uint32_t,4> stateIdentity74(){
 auto fighters=inspectSetup66(true);std::array<uint32_t,4> ids{};
 for(int i=0;i<2;i++){
  auto& f=fighters[i];ids[2*i]=f.identityA;ids[2*i+1]=f.identityB;
  if(!f.air.active)require((word(f.body+0xa0)==1&&word(f.body+0xa4)==1&&word(f.body+0x1b8)==0)||plainPunch77(f)||observedHit79(f)||observedRyo81(f)||observedRyoHit89(f),-14);
 }
 return ids;
}
#include "native-destination.h"
static float setupExecute66(int action){
 // Cancellation is safe even after Practice has ended: no game memory access,
 // slot mutation, session reset, native capture/load, or fault-latch clearing.
 if(action==14)return (float)lastStateResult;
 if(action>=9&&action<=13)return submitControllerRequest(action-9);
 if(action==8)return (float)queryStateFeedback();
 if(action==7){cancelStateMenu109();return 0;}
 if(action==5)return pollStates71();
 if(action==3){clearStates71();hasSetup66=false;loadArmed67=false;return 0;}
 // Every apply consumes its pre-reset authorization, including a failed apply.
 bool armed=loadArmed67;DWORD elapsed=GetTickCount()-loadTick67;
 if(action!=4)loadArmed67=false;
 auto current=inspectSetup66();
 if(action==1){probeCapture70();savedSetup66=current;hasSetup66=true;return 1;}
 require(hasSetup66,-12);
 for(int i=0;i<2;i++)require(current[i].actor==savedSetup66[i].actor&&current[i].identityA==savedSetup66[i].identityA&&current[i].identityB==savedSetup66[i].identityB,-15);
 if(action==0){loadArmed67=true;loadTick67=GetTickCount();return 1;}
 if(action==4)return (savedSetup66[0].x+savedSetup66[1].x)*0.5f;
 require(action==2);require(armed&&elapsed<10000,-15);
 // Validate BOTH destinations before touching either fighter.
 for(auto& f:current){valid(f.core+0xc,12,true);valid(f.core+0x28,1,true);valid(f.body+0x11c,12,true);valid(f.body+0x134,4,true);for(auto offset:{0x48,0x64,0x8c,0xc0,0xd0,0xd4})valid(f.actor+offset,4,true);}
 for(int i=0;i<2;i++)if(savedSetup66[i].air.active){auto& f=current[i];valid(f.core+0x18,12,true);valid(f.body+0x88,32,true);valid(f.body+0x128,12,true);valid(f.body+0x138,8,true);valid(f.body+0x1a0,4,true);valid(f.body+0xb4,2,true);valid(f.body+0x1e4,2,true);valid(f.body+0x114,4,true);}
 guard();
 for(int i=0;i<2;i++){
  auto f=savedSetup66[i];f.actor=current[i].actor;f.core=current[i].core;f.body=current[i].body;
  require(f.health<=word(f.actor+0x4c)&&f.stocks<=word(f.actor+0xd8),-14);
  bounded66(f.guard,0,(float)word(f.actor+0x60));bounded66(f.stun,0,(float)word(f.actor+0x88));bounded66(f.drive,0,scalar66(f.actor+0xbc));
 }
 for(int i=0;i<2;i++){
  auto f=savedSetup66[i];f.actor=current[i].actor;f.core=current[i].core;f.body=current[i].body;
  // Same cached/core and body values written by the audited position/facing setters.
  if(f.air.active){
   memcpy((void*)(f.body+0x88),f.air.animation.data(),32);
   memcpy((void*)(f.body+0x128),f.air.speed.data(),12);memcpy((void*)(f.core+0x18),f.air.speed.data(),12);
   memcpy((void*)(f.body+0x1a0),&f.air.movement,4);
   float scale[]={1,1};memcpy((void*)(f.body+0x138),scale,8);
   unsigned char flags[]={0,132};memcpy((void*)(f.body+0x1e4),flags,2);
   unsigned char zeros[]={0,0};memcpy((void*)(f.body+0xb4),zeros,2);uint32_t category=0;memcpy((void*)(f.body+0x114),&category,4);
  }
  float xyz[]={f.x,f.air.active?f.y:0,0};memcpy((void*)(f.core+0xc),xyz,12);memcpy((void*)(f.body+0x11c),xyz,12);
  *(unsigned char*)(f.core+0x28)=f.facing<0;memcpy((void*)(f.body+0x134),&f.facing,4);
  memcpy((void*)(f.actor+0x48),&f.health,4);memcpy((void*)(f.actor+0x64),&f.guard,4);memcpy((void*)(f.actor+0x8c),&f.stun,4);memcpy((void*)(f.actor+0xc0),&f.drive,4);memcpy((void*)(f.actor+0xd0),&f.power,4);memcpy((void*)(f.actor+0xd4),&f.stocks,4);
 }return 2;
}
// Test82 diagnostics only: never writes simulation or script state.
static void recoveryTrace82(int action,int count,float result){
#ifndef SLOTS_TEST
 try{auto folder=directory()+L"\\KOF13StateProbe";CreateDirectoryW(folder.c_str(),nullptr);
 std::ofstream out(folder+L"\\recovery82.jsonl",std::ios::app);
 out<<"{\"tick\":"<<GetTickCount()<<",\"pid\":"<<GetCurrentProcessId()<<",\"action\":"<<action<<",\"count\":"<<count<<",\"result\":"<<result<<",\"slot\":"<<activeState71;
 for(int i=0;i<2;i++){auto actor=word(image()+0x9b6fe8+i*4);out<<",\"health"<<i<<"\":"<<word(actor+0x48);}
 out<<"}\n";
 }catch(...){}
#endif
}
extern "C" int __cdecl KOFSetupBridge(void* state){float result=-9;auto l=(uintptr_t)state;

 try{auto base=word(l+12);require(word(l+8)>=base+8&&word(base+4)==3);float action=scalar66(base);require(action>=0&&action<=14&&action==(int)action);int counter=-1;
 if(word(l+8)>=base+16&&word(base+12)==3){float v=scalar66(base+8);if(v>=0&&v<=301&&v==(int)v)counter=(int)v;}
 if(action==6){verifyBuild();guard();require(counter==301,-14);recoveryTrace82(6,counter,0);result=0;}
 else{if(action==5)observedRecovery83=counter;result=setupExecute66((int)action);if(action==5)rememberStateResult((int)result);if(action==5&&result!=0)recoveryTrace82(5,counter,result);if(action==5&&result==2)result=1000.0f+stateSlots71[activeState71].recoveryCount;}}catch(Failure e){result=(float)e.code;stateTrace72("BRIDGE REFUSED code="+std::to_string(e.code),true);}catch(...){result=-9;stateTrace72("BRIDGE EXCEPTION",true);}
 auto top=word(l+8);valid(top,8,true);memcpy((void*)top,&result,4);*(uint32_t*)(top+4)=3;*(uint32_t*)(l+8)=top+8;return 1;
}
