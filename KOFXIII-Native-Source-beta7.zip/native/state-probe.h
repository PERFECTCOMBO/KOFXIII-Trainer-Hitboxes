// Test70: capture-only diagnostic. No restore routine is linked or called here.
// 004D4F40 checks battle_scene and constructs the game's own archive root bundle.
// 004D679F allocates returned bytes via imported malloc; 00537ADA frees them via
// the same game's imported free. Third stack argument is reserved/unused in this build.
using Capture70=bool(__stdcall*)(void**,uint32_t*,uint32_t);
using Free70=void(__cdecl*)(void*);
static Bytes copyArchive70(Capture70 capture,Free70 release){
 void* output=nullptr;uint32_t size=0;
 try{
  bool ok=capture(&output,&size,0);require(ok&&output&&size&&size<=64*1024*1024,-14);
  Bytes snapshot;snapshot.reserve(size);
  for(uint32_t offset=0;offset<size;){uint32_t count=(size-offset)>65536?65536:size-offset;auto part=read((uintptr_t)output+offset,count);snapshot.insert(snapshot.end(),part.begin(),part.end());offset+=count;}
  release(output);output=nullptr;return snapshot;
 }catch(...){if(output)release(output);throw;}
}
static void probeCapture70(){
#ifndef SLOTS_TEST
 // Invoked synchronously from a paused menu SAVE; never from a remote thread.
 static bool completed=false;if(completed)return;
 auto folder=directory()+L"\\KOF13StateProbe";
 try{
  verifyBuild();guard();auto base=image();
  require(read(base+0xd4f40,16)==Bytes({0x55,0x8b,0xec,0x6a,0xff,0x68,0xc1,0x8d,0x81,0x00,0x64,0xa1,0,0,0,0}),-8);
  for(int i=0;i<2;i++){auto actor=word(base+0x9b6fe8+i*4),core=word(word(actor+0x30)+8),body=word(core+8);require(word(core)==base+0x4ae8bc,-8);require(word(body+0xa0)==1&&word(body+0xa4)==1&&word(body+0x1b8)==0,-14);}
  require(CreateDirectoryW(folder.c_str(),nullptr)||GetLastError()==ERROR_ALREADY_EXISTS,-7);
  auto release=(Free70)word(base+0x4332c4);valid((uintptr_t)release,1);
  // Log before invocation so an interrupted attempt is distinguishable from success.
  saveFile(folder+L"\\capture-status.txt",Bytes{'S','T','A','R','T','E','D','\n'});
  auto snapshot=copyArchive70((Capture70)(base+0xd4f40),release);
  auto d=digest(snapshot);std::string hex;for(auto v:d){hex+="0123456789abcdef"[v>>4];hex+="0123456789abcdef"[v&15];}
  saveFile(folder+L"\\capture-only.bin",snapshot);
  std::string result="CAPTURED bytes="+std::to_string(snapshot.size())+" sha256="+hex+"\nCapture only; exact restoration NOT tested. No load performed.\n";
  saveFile(folder+L"\\capture-status.txt",Bytes(result.begin(),result.end()));completed=true;
 }catch(Failure e){std::string message="REFUSED code="+std::to_string(e.code)+"; no load performed\n";try{saveFile(folder+L"\\capture-status.txt",Bytes(message.begin(),message.end()));}catch(...){}}
 catch(...){std::string message="CAPTURE FAILED; no load performed\n";try{saveFile(folder+L"\\capture-status.txt",Bytes(message.begin(),message.end()));}catch(...){}}
#endif
}
