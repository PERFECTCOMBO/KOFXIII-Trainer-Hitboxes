#define WIN32_LEAN_AND_MEAN
#define DIRECTINPUT_VERSION 0x0800
#include <windows.h>
#include <dinput.h>
#include <string>

// No loader work in DllMain. Resolve the actual Windows library lazily,
// from a normal exported call; never search the game's DLL directory.
static HMODULE selfModule, systemModule;
static INIT_ONCE systemOnce = INIT_ONCE_STATIC_INIT;
static LONG launchStarted;
static BOOL CALLBACK LoadSystem(PINIT_ONCE, PVOID, PVOID*) {
    wchar_t path[32768]; DWORD n=GetModuleFileNameW(selfModule,path,32768);
    if(!n||n>=32768)return TRUE;
    std::wstring folder(path);folder.resize(folder.find_last_of(L"\\/"));
    HMODULE bridge=LoadLibraryW((folder+L"\\KOF13RecordingSlots.dll").c_str());
    if(bridge){auto install=(int(__cdecl*)())GetProcAddress(bridge,"InstallRecordingBridge");if(!install||install()!=1)OutputDebugStringW(L"KOF recording bridge installation failed.\n");}
    wchar_t sys[32768];GetSystemDirectoryW(sys,32768);systemModule=LoadLibraryW((std::wstring(sys)+L"\\dinput8.dll").c_str());    return TRUE;
}
static FARPROC Resolve(const char* name) {
    InitOnceExecuteOnce(&systemOnce, LoadSystem, nullptr, nullptr);
    return systemModule ? GetProcAddress(systemModule, name) : nullptr;
}
extern "C" HRESULT WINAPI ProxyDirectInput8Create(HINSTANCE instance,DWORD version,REFIID iid,LPVOID* output,LPUNKNOWN outer) {
    using Fn=HRESULT (WINAPI*)(HINSTANCE,DWORD,REFIID,LPVOID*,LPUNKNOWN);
    auto fn=reinterpret_cast<Fn>(Resolve("DirectInput8Create"));
    HRESULT result=fn?fn(instance,version,iid,output,outer):E_FAIL;
    return result;
}
extern "C" HRESULT WINAPI ProxyDllCanUnloadNow() { return S_FALSE; }
extern "C" HRESULT WINAPI ProxyDllGetClassObject(REFCLSID clsid,REFIID iid,LPVOID* output) {
    using Fn=HRESULT (WINAPI*)(REFCLSID,REFIID,LPVOID*);
    auto fn=reinterpret_cast<Fn>(Resolve("DllGetClassObject"));
    return fn?fn(clsid,iid,output):CLASS_E_CLASSNOTAVAILABLE;
}
extern "C" HRESULT WINAPI ProxyDllRegisterServer() {
    using Fn=HRESULT (WINAPI*)();auto fn=reinterpret_cast<Fn>(Resolve("DllRegisterServer"));return fn?fn():E_FAIL;
}
extern "C" HRESULT WINAPI ProxyDllUnregisterServer() {
    using Fn=HRESULT (WINAPI*)();auto fn=reinterpret_cast<Fn>(Resolve("DllUnregisterServer"));return fn?fn():E_FAIL;
}
extern "C" LPCDIDATAFORMAT WINAPI ProxyGetdfDIJoystick() {
    using Fn=LPCDIDATAFORMAT (WINAPI*)();auto fn=reinterpret_cast<Fn>(Resolve("GetdfDIJoystick"));return fn?fn():nullptr;
}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID) {
    if(reason==DLL_PROCESS_ATTACH) selfModule=module;
    return TRUE;
}
