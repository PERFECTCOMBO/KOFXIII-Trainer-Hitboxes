#include "state-queue.h"
#include "menu-request.h"
static MenuRequest controllerRequest;
#include "object-order.h"
#include "parent-order.h"
#include "rng-state.h"
#include "effect-init.h"
// Test71: native archive roundtrip experiment, menu-thread only.
// Same live Practice session. Never imports the Test70 disk archive.
using Load71=bool(__stdcall*)(void**,uint32_t,uint32_t);
struct NativeSlot71 {bool hasParents103=false;ParentSnapshot103 parents103;bool hasRng95=false;Rng95 rng95;bool hasOrder87=false;OrderSaved87 order87;Bytes data,hash;int recoveryCount=-1;uint64_t epoch=0;std::array<uint32_t,4> identity{};};
static std::array<NativeSlot71,3> stateSlots71{};
static int lastStateResult=0;
static void rememberStateResult(int result){if(result!=0)lastStateResult=result;}
static uint64_t stateEpoch71=1;static int activeState71=0;static bool stateFault71=false;
// Menu preflight: report an empty slot before inspecting its unset recovery count.
// Retain the fault latch and recovery bounds; this never touches game memory.
static void validateMenuLoadSlot110(const NativeSlot71& slot){
 require(!stateFault71,-14);
 require(!slot.data.empty(),-12);
 require(slot.recoveryCount>=0&&slot.recoveryCount<=300,-14);
}
static void clearStates71(){lastStateResult=0;controllerRequest.cancel();stateQueue107.cancel();stateSlots71={};stateEpoch71++;stateFault71=false;activeState71=0;}
// Read-only cached status for menu feedback. Bits0..1 active slot (1..3),
// bits2..4 occupied slots, bit5 native fault, bit6 queued request.
// No game-memory reads, loader calls, queue consumption or slot mutation.
static int queryStateFeedback(){
 int value=activeState71+1;
 for(int i=0;i<3;i++)if(!stateSlots71[i].data.empty())value|=1<<(i+2);
 if(stateFault71)value|=32;
 if(stateQueue107.pending()||controllerRequest.pending())value|=64;
 return value;
}
// Defined after the audited plain-air inspector in setup.h.
static std::array<uint32_t,4> stateIdentity74();
static std::array<uint32_t,4> nativeDestination104();
static std::array<uint32_t,4> stateIdentityForRequest106(int request,bool loadOptIn,bool captureOptIn);
static void stateLog71(const std::string& message){
#ifndef SLOTS_TEST
 try{auto folder=directory()+L"\\KOF13StateProbe";require(CreateDirectoryW(folder.c_str(),nullptr)||GetLastError()==ERROR_ALREADY_EXISTS,-7);auto text="slot="+std::to_string(activeState71+1)+" "+message+"\n";saveFile(folder+L"\\load-test-status.txt",Bytes(text.begin(),text.end()));}catch(...){}
#endif
}
// Test76: compare native archive bytes at the same paused callback boundary.
// This is a serializer roundtrip diagnostic, not a full simulation checksum.
static std::string archiveRoundtrip76(const Bytes& expected,const Bytes& actual){
 size_t differing=0,first=(size_t)-1;size_t common=expected.size()<actual.size()?expected.size():actual.size();
 for(size_t i=0;i<common;i++)if(expected[i]!=actual[i]){if(first==(size_t)-1)first=i;differing++;}
 differing+=expected.size()>actual.size()?expected.size()-actual.size():actual.size()-expected.size();
 if(differing&&first==(size_t)-1)first=common;
 return std::string(differing?"ARCHIVE_DIFFERENT":"ARCHIVE_IDENTICAL")+" expected="+std::to_string(expected.size())+" actual="+std::to_string(actual.size())+" differing="+std::to_string(differing)+(differing?" first="+std::to_string(first):"");
}
// Validate before invoking the native reader. Return 2 only after native success.
static int restoreSlot71(NativeSlot71& slot,const std::array<uint32_t,4>& ids,Capture70 capture,Free70 release,Load71 load){
 require(!stateFault71,-14);require(!slot.data.empty(),-12);require(slot.epoch==stateEpoch71&&slot.identity==ids,-15);require(digest(slot.data)==slot.hash,-5);
 if(slot.hasRng95)validateRng95(slot.rng95);
 Rng95 recoveryRng95;if(slot.hasRng95)recoveryRng95=captureRng95();
 auto recovery=copyArchive70(capture,release);if(slot.hasRng95)require(captureRng95().data==recoveryRng95.data,-17);auto target=slot.data;void* ptr=target.data();bool loaded=false;
 stateLog71("LOAD STARTED; recovery snapshot held in memory");
 try{loaded=load(&ptr,(uint32_t)target.size(),0);}catch(...){loaded=false;}
 if(!loaded){ptr=recovery.data();bool recovered=false;try{recovered=load(&ptr,(uint32_t)recovery.size(),0);}catch(...){recovered=false;}if(recovered&&slot.hasRng95){try{restoreRng95(recoveryRng95);}catch(...){recovered=false;}}stateFault71=true;stateLog71(recovered?"LOAD FAILED; recovery returned success; restart before further tests":"LOAD FAILED; recovery failed; restart game");return -16;}
 try{
  if(slot.hasParents103){require(slot.hasOrder87,-14);restoreLists103(slot.order87,slot.parents103);}else if(slot.hasOrder87)restoreOrder87(slot.order87);
  auto observed=copyArchive70(capture,release);
  auto diagnostic=archiveRoundtrip76(slot.data,observed);
#ifndef SLOTS_TEST
  auto folder=directory()+L"\\KOF13StateProbe";
  // Preserve the latest pair locally for byte/schema analysis; never import it.
  if(observed!=slot.data){saveFile(folder+L"\\roundtrip-expected.bin",slot.data);saveFile(folder+L"\\roundtrip-observed.bin",observed);}
#endif
  if(slot.hasRng95){require(observed==slot.data,-17);restoreRng95(slot.rng95);}
  stateLog71("NATIVE LOAD RETURNED SUCCESS; "+diagnostic+(slot.hasRng95?"; PRNG_IDENTICAL":"")+"; gameplay correctness still requires checking");
 }catch(...){stateFault71=true;stateLog71("NATIVE LOAD RETURNED SUCCESS; POSTCHECK FAILED; restart before further tests");return -17;}
 return 2;
}
// Throttled diagnostics: test shortcut keys only.
static void stateTrace72(const std::string& phase,bool force=false){
#ifndef SLOTS_TEST
 static DWORD previous=0;static unsigned long calls=0;calls++;auto now=GetTickCount();if(!force&&now-previous<1000)return;previous=now;
 try{auto folder=directory()+L"\\KOF13StateProbe";CreateDirectoryW(folder.c_str(),nullptr);auto text="pid="+std::to_string(GetCurrentProcessId())+" thread="+std::to_string(GetCurrentThreadId())+" calls="+std::to_string(calls)+" tick="+std::to_string(now)+" "+phase+"\n";saveFile(folder+L"\\input-test-status.txt",Bytes(text.begin(),text.end()));}catch(...){}
#endif
}
static int observedRecovery83=-1;
// Test109: a paused-menu lifetime must not carry a request or held shortcut
// into a later opening. Called by an explicit Lua entry/exit notification.
static bool stateHeld109[5]={};
static void cancelStateMenu109(){
 if(controllerRequest.pending()||stateQueue107.pending())lastStateResult=-18;
 controllerRequest.cancel();stateQueue107.cancel();
 // Require release before accepting a shortcut already held at menu entry.
 for(auto& held:stateHeld109)held=true;
}
static int sampleStateInput109(bool ctrl,const bool down[5],int& count){
 int request=-1;count=0;
 for(int i=0;i<5;i++){
  bool pressed=ctrl&&down[i];
  if(pressed){count++;if(!stateHeld109[i])request=i;}
  stateHeld109[i]=pressed;
 }
 return request;
}
// Admission is supplied by the real paused-menu bridge below; fixture callers
// exercise the same state transition without OS or game access.
static int stageControllerRequest(int action,bool allowed,uint32_t tick,uint32_t thread){
 if(!allowed||stateFault71||stateQueue107.pending()){
  controllerRequest.cancel();stateQueue107.cancel();return -14;
 }
 if(!controllerRequest.submit(action,stateEpoch71,tick,thread))return -14;
 return 0;
}
// Slot selection alone is safe without enabling native save/load dispatch.
// Call only after the real bridge validates build, offline Practice and pause.
static int selectDisabledMenuSlot113(int action,bool foreground){
 if(action<2||action>4||!foreground||stateFault71||controllerRequest.pending()||stateQueue107.pending())return -14;
 activeState71=action-2;return 0;
}
static float submitControllerRequest(int action){
 try{
  verifyBuild();guard();auto base=image();
  require(read(base+0x99e7ec,1)[0]!=0&&read(base+0x9b6ff8,1)[0]!=0,-14);
  DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);
  bool enabled=GetPrivateProfileIntW(L"Experimental",L"QueuedMenu107",1,(directory()+L"\\KOF13StateTest.ini").c_str())==1;
  if(!enabled&&action>=2&&action<=4){
   int result=selectDisabledMenuSlot113(action,foreground==GetCurrentProcessId());
   lastStateResult=result;
   stateLog71(result==0?(stateSlots71[activeState71].data.empty()?"EMPTY":"READY"):"MENU REQUEST REFUSED");
   return (float)result;
  }
  int result=stageControllerRequest(action,enabled&&foreground==GetCurrentProcessId(),GetTickCount(),GetCurrentThreadId());
  lastStateResult=result;stateLog71(result==0?"MENU REQUEST STAGED":"MENU REQUEST REFUSED");return (float)result;
 }catch(Failure f){controllerRequest.cancel();stateQueue107.cancel();lastStateResult=f.code;return (float)f.code;}
 catch(...){controllerRequest.cancel();stateQueue107.cancel();lastStateResult=-9;return -9;}
}
static float pollStates71(){
#ifndef SLOTS_TEST
 auto& held=stateHeld109;static int keys[5]={VK_F5,VK_F7,'1','2','3'};static bool configured=false;
 if(!configured){auto path=directory()+L"\\KOF13StateTest.ini";const wchar_t* names[]={L"SaveKey",L"LoadKey",L"Slot1Key",L"Slot2Key",L"Slot3Key"};std::set<int> unique;bool good=true;int candidate[5];for(int i=0;i<5;i++){candidate[i]=GetPrivateProfileIntW(L"Shortcuts",names[i],keys[i],path.c_str());good=good&&candidate[i]>=0x30&&candidate[i]<=0xfe&&unique.insert(candidate[i]).second;}if(good)memcpy(keys,candidate,sizeof(keys));configured=true;}
 DWORD foreground=0;GetWindowThreadProcessId(GetForegroundWindow(),&foreground);bool ctrl=(GetAsyncKeyState(VK_CONTROL)&0x8000)!=0;int count=0;bool down[5];
 for(int i=0;i<5;i++)down[i]=(GetAsyncKeyState(keys[i])&0x8000)!=0;
 int request=sampleStateInput109(ctrl,down,count);
 stateTrace72("POLL ctrl="+std::to_string(ctrl)+" held="+std::to_string(held[0])+std::to_string(held[1])+std::to_string(held[2])+std::to_string(held[3])+std::to_string(held[4])+" request="+std::to_string(request)+" foreground="+std::to_string(foreground),request>=0);
 bool queuedMode=GetPrivateProfileIntW(L"Experimental",L"QueuedMenu107",1,(directory()+L"\\KOF13StateTest.ini").c_str())==1;
 if(foreground!=GetCurrentProcessId()||count>1){if(controllerRequest.pending()||stateQueue107.pending())lastStateResult=-18;controllerRequest.cancel();stateQueue107.cancel();return 0;}
 if(!queuedMode){if(controllerRequest.pending()||stateQueue107.pending())lastStateResult=-18;controllerRequest.cancel();stateQueue107.cancel();}
 if(controllerRequest.pending()){
  int menuAction=controllerRequest.take(stateEpoch71,GetTickCount(),GetCurrentThreadId(),queuedMode&&count==0&&!stateFault71);
  if(menuAction<0){stateQueue107.cancel();lastStateResult=-18;stateLog71("MENU REQUEST CANCELED");return 0;}
  request=menuAction;
 }
 if(request<0&&!stateQueue107.pending())return 0;
 try{
  verifyBuild();guard();require(!stateFault71,-14);
  if(queuedMode){
   if(stateQueue107.pending()){
    // A new edge cancels the pending operation rather than changing its target slot.
    require(request<0,-14);StateRequest107 saved;
    require(stateQueue107.take(stateEpoch71,GetTickCount(),GetCurrentThreadId(),!stateFault71,saved),-14);
    request=saved.action;require(activeState71==saved.slot,-14);
   }else if(request>=0&&request<2){
    require(stateQueue107.submit(request,activeState71,stateEpoch71,GetTickCount(),GetCurrentThreadId()),-14);
    lastStateResult=0;stateLog71("QUEUED; awaiting next paused callback");return 0;
   }
  }
  if(request>=2){lastStateResult=0;activeState71=request-2;stateLog71(stateSlots71[activeState71].data.empty()?"EMPTY":"READY");return 0;}
  require(observedRecovery83>=0&&observedRecovery83<=300,-14);
  if(request==1)validateMenuLoadSlot110(stateSlots71[activeState71]);
  // Menu114: queued menu and validated native capture are available without a test INI.
  // Explicit diagnostic opt-outs remain; LOAD destination admission is unchanged.
  bool destinationExperiment=request==1&&GetPrivateProfileIntW(L"Experimental",L"LoadDestination104",0,(directory()+L"\\KOF13StateTest.ini").c_str())==1;
  bool captureExperiment=request==0&&GetPrivateProfileIntW(L"Experimental",L"CaptureState106",1,(directory()+L"\\KOF13StateTest.ini").c_str())==1;
  auto ids=stateIdentityForRequest106(request,destinationExperiment,captureExperiment);auto base=image();
  try{installEffectHooks100();}catch(...){stateFault71=true;throw;}
  require(read(base+0xd4f40,16)==Bytes({0x55,0x8b,0xec,0x6a,0xff,0x68,0xc1,0x8d,0x81,0,0x64,0xa1,0,0,0,0}),-8);
  require(read(base+0xd50c0,16)==Bytes({0x55,0x8b,0xec,0x6a,0xff,0x68,0xf1,0x8d,0x81,0,0x64,0xa1,0,0,0,0}),-8);
  auto capture=(Capture70)(base+0xd4f40);auto release=(Free70)word(base+0x4332c4);auto& slot=stateSlots71[activeState71];
  if(request==0){NativeSlot71 candidate;candidate.rng95=captureRng95();candidate.hasRng95=true;candidate.order87=saveOrder87();candidate.hasOrder87=true;candidate.parents103=saveParents103();candidate.hasParents103=true;candidate.data=copyArchive70(capture,release);require(captureRng95().data==candidate.rng95.data,-17);candidate.hash=digest(candidate.data);candidate.identity=ids;candidate.epoch=stateEpoch71;candidate.recoveryCount=observedRecovery83;slot=std::move(candidate);stateLog71("CAPTURED bytes="+std::to_string(slot.data.size()));return 1;}
  return (float)restoreSlot71(slot,ids,capture,release,(Load71)(base+0xd50c0));
 }catch(Failure f){stateQueue107.cancel();stateLog71("REFUSED code="+std::to_string(f.code));return (float)f.code;}catch(...){stateQueue107.cancel();stateLog71("REQUEST FAILED");return -9;}
#else
 return 0;
#endif
}
#pragma comment(lib,"user32.lib")
