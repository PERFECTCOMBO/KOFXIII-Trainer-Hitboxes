// Test104: destination validation for native LOAD only. No scalar reconstruction.
// A target's saved animation is validated at capture. Current animation need not
// equal the target, but loading remains synchronous inside paused offline Practice.
static std::array<uint32_t,4> nativeDestination104(){
 verifyBuild();guard();std::array<uint32_t,4> ids{};
 std::set<uintptr_t> actors,wrappers,cores,bodies;
 std::vector<std::pair<uintptr_t,Bytes>> identityChecks;
 auto remember=[&](uintptr_t p,size_t n){auto b=read(p,n);identityChecks.push_back({p,b});return b;};
 remember(image()+0x9b6fe8,8);
 for(int side=0;side<2;side++){
  auto actor=word(image()+0x9b6fe8+side*4);require(actors.insert(actor).second,-14);
  require(word(actor)==image()+0x4be768,-8);remember(actor+0x20,8);remember(actor+0x30,4);
  auto wrapper=word(actor+0x30);require(wrappers.insert(wrapper).second&&word(wrapper)==image()+0x4adea8,-8);remember(wrapper+8,4);
  auto core=word(wrapper+8);require(cores.insert(core).second&&word(core)==image()+0x4ae8bc,-8);remember(core+8,4);
  auto body=word(core+8);require(bodies.insert(body).second&&word(body)==image()+0x4ad24c,-8);
  ids[2*side]=word(actor+0x20);ids[2*side+1]=word(actor+0x24);
  require(ids[2*side]<=37&&ids[2*side+1]<=1,-14);
  // Reject KO/transition and malformed numeric state. Do not interpret action IDs.
  auto health=word(actor+0x48),maxHealth=word(actor+0x4c);require(health>0&&maxHealth<=100000&&health<=maxHealth,-14);
  bounded66(scalar66(body+0x11c),-2000,2000);bounded66(scalar66(body+0x120),-1000,2000);bounded66(scalar66(body+0x124),-2000,2000);
  auto facing=scalar66(body+0x134);require(facing==1||facing==-1,-14);
  for(auto p:{body+0x128,body+0x12c,body+0x130})bounded66(scalar66(p),-1000,1000);
  bounded66(scalar66(actor+0x64),0,(float)word(actor+0x60));bounded66(scalar66(actor+0x8c),0,(float)word(actor+0x88));
  bounded66(scalar66(actor+0xc0),0,scalar66(actor+0xbc));bounded66(scalar66(actor+0xd0),0,1000);
  require(word(actor+0xd4)<=word(actor+0xd8),-14);
 }
 // Recheck identity chain before returning; no writes or native calls here.
 for(auto& c:identityChecks)require(read(c.first,c.second.size())==c.second,-14);
 return ids;
}

// Test106: independent, default-off capture experiment. Native archive only.
// No restart/scalar setup path, object recreation or serializer ownership changes.
static std::array<uint32_t,4> stateIdentityForRequest106(int request,bool loadOptIn,bool captureOptIn){
 require(request==0||request==1,-14);
 return ((request==0&&captureOptIn)||(request==1&&loadOptIn))?nativeDestination104():stateIdentity74();
}
