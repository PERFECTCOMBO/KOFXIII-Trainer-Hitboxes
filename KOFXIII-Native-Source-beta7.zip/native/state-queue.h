// Test107: callback-local queue, not a cross-thread submission API.
// No native game operations occur here. Requests expire instead of surviving a menu/session exit.
struct StateRequest107 { int action=-1,slot=-1; uint64_t epoch=0; uint32_t tick=0,thread=0; };
class StateQueue107 {
 bool pending_=false; StateRequest107 request_{};
public:
 bool pending()const{return pending_;}
 void cancel(){pending_=false;request_={};}
 bool submit(int action,int slot,uint64_t epoch,uint32_t tick,uint32_t thread){
  if(pending_||action<0||action>1||slot<0||slot>2||!thread)return false;
  request_={action,slot,epoch,tick,thread};pending_=true;return true;
 }
 // Always consume before dispatch, including refusal: no retry of a native failure.
 bool take(uint64_t epoch,uint32_t tick,uint32_t thread,bool allowed,StateRequest107& out){
  out={};if(!pending_)return false;auto saved=request_;cancel();
  if(!allowed||saved.epoch!=epoch||saved.thread!=thread||uint32_t(tick-saved.tick)>1000)return false;
  out=saved;return true;
 }
};
static StateQueue107 stateQueue107;
