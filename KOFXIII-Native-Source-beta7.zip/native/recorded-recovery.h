#pragma once
// Observation only: never replaces the game's input mask. These transitions are
// narrowly evidenced for Ryo P2, not a roster-wide actionable-frame predicate.
struct RecordedRecovery125 {
 unsigned mode=0, actor=0, body=0, queued=0;
 bool sawBlock=false,sawWake=false;
 void clear(){sawBlock=sawWake=false;queued=0;}
 void cancel(){mode=0;clear();actor=body=0;}
 bool arm(unsigned trigger){cancel();if(trigger!=1&&trigger!=3)return false;mode=trigger;return true;}
 void observe(unsigned who,unsigned address,unsigned primary,unsigned secondary,unsigned flags){
  if(!mode)return;
  if(actor&&(actor!=who||body!=address)){cancel();return;}
  actor=who;body=address;
  if(primary==109){sawBlock=false;if(secondary==109)sawWake=true;}
  if(primary==80&&secondary==80)sawBlock=true;
  bool fire=!(flags&8)&&((mode==1&&sawBlock&&primary==80&&secondary==72)||(mode==3&&sawWake&&primary==109&&secondary==1));
  if(primary!=80)sawBlock=false;
  if(primary!=109)sawWake=false;
  if(fire){queued=mode;mode=0;sawBlock=sawWake=false;}
 }
 unsigned take(){auto value=queued;queued=0;return value;}
};
