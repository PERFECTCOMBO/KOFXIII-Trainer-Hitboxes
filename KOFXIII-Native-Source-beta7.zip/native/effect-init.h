// Test100 candidate: deterministic default flag initialization in offline Practice only.
// Native constructors and the native archive reader still own object creation/payload.
// Installed lazily inside the paused save-state callback; never an object-recreation pass.
struct EffectHook100 {uintptr_t site=0;unsigned char* stub=nullptr;Bytes original,patch;DWORD protection=0;};
static std::vector<EffectHook100> effectHooks100;
static bool effectsInstalled100=false;

static Bytes effectStub100(uintptr_t base,uintptr_t code,uintptr_t resume){
 Bytes b{0x9c};std::vector<size_t> skip;
 auto jne=[&](){b.push_back(0x75);skip.push_back(b.size());b.push_back(0);};
 b.insert(b.end(),{0x80,0x3d});append32(b,(uint32_t)(base+0x594557));b.push_back(1);jne();
 for(auto offset:{0x999178u,0x9b0684u}){b.insert(b.end(),{0x83,0x3d});append32(b,(uint32_t)(base+offset));b.push_back(0);jne();}
 b.insert(b.end(),{0x81,0x3d});append32(b,(uint32_t)(base+0x9e1de8));append32(b,(uint32_t)(base+0x4ba54c));jne();
 // Restore incoming flags before reproducing the experimental AND AL,0 semantics.
 b.insert(b.end(),{0x9d,0x24,0x00,0xeb,0x01});
 auto outside=b.size();b.push_back(0x9d);
 for(auto at:skip){require(outside-at-1<128);b[at]=(unsigned char)(outside-at-1);}
 b.insert(b.end(),{0x88,0x87,0xe5,0x01,0x00,0x00,0xe9});
 append32(b,(uint32_t)(resume-(code+b.size()+4)));return b;
}
#ifdef SLOTS_TEST
static int effectFailWrite100=0,effectWriteCount100=0;static bool effectFailAfter100=false;
#endif
static void writeEffectCode100(const EffectHook100& h,const Bytes& bytes){
#ifdef SLOTS_TEST
 bool injected=(++effectWriteCount100==effectFailWrite100);
 if(injected&&!effectFailAfter100)throw Failure{-9};
#endif
 DWORD prior=0,unused=0;require(VirtualProtect((void*)h.site,bytes.size(),PAGE_EXECUTE_READWRITE,&prior)!=0,-9);
 memcpy((void*)h.site,bytes.data(),bytes.size());
 bool flushed=FlushInstructionCache(GetCurrentProcess(),(void*)h.site,bytes.size())!=0;
 bool protectedAgain=VirtualProtect((void*)h.site,bytes.size(),h.protection,&unused)!=0;
 require(flushed&&protectedAgain,-9);require(read(h.site,bytes.size())==bytes,-9);
#ifdef SLOTS_TEST
 if(injected&&effectFailAfter100)throw Failure{-9};
#endif
}
static void removeEffectHooks100(){
 // Do not free a trampoline unless every site has been restored. Unknown ownership fails closed.
 for(auto& h:effectHooks100){auto current=read(h.site,6);require(current==h.original||current==h.patch,-17);}
 for(auto& h:effectHooks100)writeEffectCode100(h,h.original);
 for(auto& h:effectHooks100)if(h.stub)VirtualFree(h.stub,0,MEM_RELEASE);
 effectHooks100.clear();effectsInstalled100=false;
}
static void installEffectHooks100(){
 auto base=image();
 if(effectsInstalled100){for(auto& h:effectHooks100)require(read(h.site,6)==h.patch,-17);return;}
 require(effectHooks100.empty(),-17);
 const Bytes context{0x24,0xbf,0x88,0x87,0xe5,0x01,0x00,0x00};
 for(auto offset:{0x4e852u,0x4ef62u})require(read(base+offset-2,8)==context,-8);
 try{
  for(auto offset:{0x4e852u,0x4ef62u}){
   EffectHook100 h;h.site=base+offset;h.original=read(h.site,6);
   MEMORY_BASIC_INFORMATION mbi{};require(VirtualQuery((void*)h.site,&mbi,sizeof(mbi))==sizeof(mbi),-9);h.protection=mbi.Protect;
   effectHooks100.push_back(h);auto& stored=effectHooks100.back();
   stored.stub=(unsigned char*)VirtualAlloc(nullptr,128,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);require(stored.stub!=nullptr,-9);
   auto code=effectStub100(base,(uintptr_t)stored.stub,stored.site+6);require(code.size()<=128);memcpy(stored.stub,code.data(),code.size());
   DWORD old=0;require(VirtualProtect(stored.stub,128,PAGE_EXECUTE_READ,&old)!=0,-9);require(FlushInstructionCache(GetCurrentProcess(),stored.stub,code.size())!=0,-9);
   stored.patch={0xe9};append32(stored.patch,(uint32_t)((uintptr_t)stored.stub-stored.site-5));stored.patch.push_back(0x90);
  }
  for(auto& h:effectHooks100)writeEffectCode100(h,h.patch);
  effectsInstalled100=true;
 }catch(...){
  // Retain buffers if cleanup fails: leaking at most two small blocks is safer than dangling jumps.
  try{removeEffectHooks100();}catch(...){throw Failure{-17};}
  throw;
 }
}
