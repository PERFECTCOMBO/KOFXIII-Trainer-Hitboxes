// Test 63: suppress only the audited battle composition layers. No actor or
// simulation writes. The exact scene file is required because scale identifies
// these layers in this build; unknown scene layouts fail closed.
static bool hideCharacters=false;
using CopyUpdate=void(__thiscall*)(void*,void*);
static CopyUpdate originalCopyUpdate=nullptr;
static bool hiddenLayer(bool hidden,bool offline,bool online,uint32_t x,uint32_t y){return hidden&&offline&&!online&&x==0x3f900000&&y==0x3f900000;}
static void __fastcall visibilityCopyUpdate(void* node,void*,void* table){
 bool skip=false;
 try{bool offline=read(image()+0x594557,1)[0]==1,online=word(image()+0x999178)!=0;
 if(!offline||online)hideCharacters=false;
 skip=hiddenLayer(hideCharacters,offline,online,word((uintptr_t)node+0x44),word((uintptr_t)node+0x48));
 }catch(...){hideCharacters=false;}
 if(!skip)originalCopyUpdate(node,table);
}
// BattlerNode +0x40 is constructed at 0x59ddc2 by 0x59c840 using
// fighter_shadow_composite. Only its draw-table submission is intercepted.
using ShadowSubmit=void(__thiscall*)(void*,void*,int,int);
static ShadowSubmit originalShadowSubmit=nullptr;
static bool shadowsHidden(){
 try{bool offline=read(image()+0x594557,1)[0]==1,online=word(image()+0x999178)!=0;
 if(!offline||online)hideCharacters=false;
 return hideCharacters&&offline&&!online;
 }catch(...){hideCharacters=false;return false;}
}
static void __fastcall visibilityShadowSubmit(void* table,void*,void* ref,int priority,int flag){
 if(!shadowsHidden())originalShadowSubmit(table,ref,priority,flag);
}
static void installVisibilityHooks(){
 if(originalCopyUpdate)return;
 auto slot=image()+0x4c4334,call=image()+0x19ef11;
 require(word(slot)==image()+0x1c2fd0,-8);
 require(read(call,5)==Bytes({0xe8,0xfa,0x7b,0x02,0x00}),-8);
 unsigned char patch[5]={0xe8};auto delta=(uint32_t)((uintptr_t)&visibilityShadowSubmit-call-5);memcpy(patch+1,&delta,4);
 DWORD slotOld,callOld,unused;
 require(VirtualProtect((void*)slot,4,PAGE_READWRITE,&slotOld)!=0);
 if(!VirtualProtect((void*)call,5,PAGE_EXECUTE_READWRITE,&callOld)){
 VirtualProtect((void*)slot,4,slotOld,&unused);throw Failure{-9};}
 originalShadowSubmit=(ShadowSubmit)(image()+0x1c6b10);
 originalCopyUpdate=(CopyUpdate)(image()+0x1c2fd0);
 memcpy((void*)call,patch,5);FlushInstructionCache(GetCurrentProcess(),(void*)call,5);
 InterlockedExchange((volatile LONG*)slot,(LONG)&visibilityCopyUpdate);
 VirtualProtect((void*)call,5,callOld,&unused);VirtualProtect((void*)slot,4,slotOld,&unused);
}
static int visibilityExecute(int mode){
 require(mode>=0&&mode<=2);verifyBuild();
 if(mode!=2){hideCharacters=false;return mode;}
 require(read(image()+0x594557,1)[0]==1,-1);require(word(image()+0x999178)==0,-2);
 auto hash=digest(fileRead(directory()+L"\\script\\scene_config.lua",4*1024*1024));
 const unsigned char expected[]={0x14,0x03,0x40,0xa7,0x42,0xdd,0x8d,0xcc,0x7f,0x5d,0x58,0x66,0x72,0x3f,0x53,0xf2,0xad,0x59,0xd1,0xa7,0x44,0xd1,0xc1,0x7e,0xd5,0xf2,0x7c,0xc6,0x62,0x39,0x1b,0x90};
 require(hash==Bytes(expected,expected+32),-8);
 installVisibilityHooks();
 hideCharacters=true;return mode;
}
extern "C" int __cdecl KOFVisibilityBridge(void* state){int result=-9;auto l=(uintptr_t)state;
 try{auto base=word(l+12);require(word(l+8)>=base+8&&word(base+4)==3);float mode;auto b=read(base,4);memcpy(&mode,b.data(),4);require(mode>=0&&mode<=2&&mode==(int)mode);result=visibilityExecute((int)mode);}catch(Failure e){result=e.code;}catch(...){result=-9;}
 auto top=word(l+8);valid(top,8,true);float f=(float)result;memcpy((void*)top,&f,4);*(uint32_t*)(top+4)=3;*(uint32_t*)(l+8)=top+8;return 1;
}
