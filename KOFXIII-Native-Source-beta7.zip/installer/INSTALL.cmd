@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup.ps1" -Action Install
pause
