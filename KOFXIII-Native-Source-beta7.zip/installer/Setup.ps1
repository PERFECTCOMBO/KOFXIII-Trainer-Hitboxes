param([ValidateSet('Install','Restore')][string]$Action='Install',[string]$GameRoot)
$ErrorActionPreference='Stop'
function FileHash([string]$path){
 $stream=[IO.File]::OpenRead($path);$algorithm=[Security.Cryptography.SHA256]::Create()
 try{return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-','').ToLowerInvariant()}finally{$algorithm.Dispose();$stream.Dispose()}
}
try {
 if(!$GameRoot){$GameRoot=Read-Host 'Paste your XIII Global Match game folder (Steam > Manage > Browse local files)'}
 $root=[IO.Path]::GetFullPath($GameRoot.Trim().Trim('"')).TrimEnd('\')
 if(!(Test-Path -LiteralPath (Join-Path $root 'game.exe'))){throw 'game.exe was not found in that folder.'}
 $gameHash=FileHash (Join-Path $root 'game.exe')
 if($gameHash -ne 'E7718F5C553DE852135DDEF5833A7BB6EAFD05508D1206AC6F3CE7767B474835'){throw "Unsupported game.exe version. Found SHA256: $gameHash. Expected: E7718F5C553DE852135DDEF5833A7BB6EAFD05508D1206AC6F3CE7767B474835. Select the Steam GLOBAL MATCH installation, not the debug or original Steam Edition build. No files changed."}
 if(Get-Process | Where-Object {try{$_.Path -and $_.Path.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)}catch{$false}}){throw 'Close XIII and the hitbox viewer first.'}
 $allowed=@('dinput8.dll','KOF13InputChain.dll','KOF13NativeHitboxes.dll','KOF13RecordingSlots.dll','KOF13HITBOX/disabled.txt','script/main.lua','ui/practice_menu.gfx','ui/practice_score_board.gfx')
 function Target([string]$rel){if($rel -notin $allowed){throw 'Unexpected installer path'};return Join-Path $root $rel}
 function Hash([string]$path){if(Test-Path -LiteralPath $path){return (FileHash $path)};return $null}
 $backup=Join-Path $root '_KOF13TrainerHitboxesBeta7_Backup';$statePath=Join-Path $backup 'state.json'
 if($Action -eq 'Restore'){
  if(!(Test-Path -LiteralPath $statePath)){throw 'No training backup found in this game folder.'}
  $state=Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
  if($state.status -eq 'restored'){Write-Host 'Already restored.';exit 0}
  foreach($item in $state.files){$dest=Target $item.path;$current=Hash $dest;if($current -ne $item.installed -and $current -ne $item.original){throw "File changed since installation: $($item.path). Restore it manually from the backup to avoid overwriting a newer mod."};if($item.original -and (Hash (Join-Path $backup $item.path)) -ne $item.original){throw 'Backup checksum mismatch'}}
  foreach($item in $state.files){$dest=Target $item.path;if($item.original){Copy-Item -LiteralPath (Join-Path $backup $item.path) -Destination $dest -Force}else{if(Test-Path -LiteralPath $dest){Remove-Item -LiteralPath $dest}};if((Hash $dest) -ne $item.original){throw 'Restore verification failed'}}
  $state.status='restored';$state | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $statePath
  Write-Host 'Restored your exact pre-install files. Saved recordings were preserved.';exit 0
 }
 if(Test-Path -LiteralPath $backup){throw 'A previous training backup exists. Keep it; restore or move the old backup outside the game folder before a new installation.'}
 # Match only files this integration depends on; unrelated artwork/audio/assets are untouched.
 $profiles=Get-Content "$PSScriptRoot\profiles.json" -Raw | ConvertFrom-Json
 $profile=$null
 foreach($candidate in $profiles){
  $matches=$true
  foreach($required in $candidate.requirements){
   $requiredPath=[IO.Path]::GetFullPath((Join-Path $root $required.path))
   if(!$requiredPath.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid prerequisite path'}
   if((Hash $requiredPath) -ne $required.sha256){$matches=$false;break}
  }
  if($matches){$profile=$candidate;break}
 }
 if(!$profile){
  $reports=@(foreach($candidate in $profiles){
   $differences=@(foreach($required in $candidate.requirements){
    $actual=Hash (Join-Path $root $required.path)
    if($actual -ne $required.sha256){
     $found=if($actual){$actual}else{'MISSING'}
     $expected=if($required.sha256){$required.sha256}else{'ABSENT'}
     "$($required.path): found $found; expected $expected"
    }
   })
   [pscustomobject]@{id=$candidate.id;differences=$differences;count=$differences.Count}
  })
  $closest=$reports | Sort-Object count | Select-Object -First 1
  throw ("No supported installation profile matched. Closest: $($closest.id).`r`n"+($closest.differences -join "`r`n")+"`r`nSupported: clean Steam GLOBAL MATCH or standalone Trainer Beta 6. No files changed. Send this error before changing your files.")
 }
 Write-Host "Detected compatibility profile: $($profile.id)"
 $manifest=Get-Content "$PSScriptRoot\manifest.json" -Raw | ConvertFrom-Json
 $plans=@();foreach($item in $manifest){
  $dest=Target $item.path;$source=Join-Path "$PSScriptRoot\payload" $item.path
  if((Hash $source) -ne $item.sha256){throw 'Package checksum mismatch'}
  $override=$profile.overrides | Where-Object path -eq $item.path
  if($override){$item=$override;$source=Join-Path $PSScriptRoot $override.source}
  $source=[IO.Path]::GetFullPath($source)
  if(!$source.StartsWith($PSScriptRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid package path'}
  if((Hash $source) -ne $item.sha256){throw 'Package checksum mismatch'}
  $plans+=@{path=$item.path;source=$source;original=(Hash $dest);installed=$item.sha256}
 }
 foreach($extra in $profile.overrides | Where-Object {$_.path -notin $manifest.path}){
  $dest=Target $extra.path;$source=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot $extra.source))
  if(!$source.StartsWith($PSScriptRoot+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid package path'}
  if((Hash $source) -ne $extra.sha256){throw 'Package checksum mismatch'}
  $plans+=@{path=$extra.path;source=$source;original=(Hash $dest);installed=$extra.sha256}
 }
 # Refuse unrecognized files even when the compatibility profile has no prerequisite for them.
 foreach($item in $plans){
  $requirement=$profile.requirements | Where-Object path -eq $item.path
  if(!$requirement -and $item.original -and $item.original -ne $item.installed){throw "Conflicting destination: $($item.path). No files changed."}
 }
 New-Item -ItemType Directory -Path $backup | Out-Null
 foreach($item in $plans){if($item.original){$saved=Join-Path $backup $item.path;New-Item -ItemType Directory -Force (Split-Path $saved) | Out-Null;Copy-Item -LiteralPath (Target $item.path) -Destination $saved;if((Hash $saved) -ne $item.original){throw 'Backup verification failed'}}}
 $state=@{status='installing';files=@($plans | ForEach-Object {@{path=$_.path;original=$_.original;installed=$_.installed}})}
 $state | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $statePath
 try{foreach($item in $plans){$dest=Target $item.path;New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null;Copy-Item -LiteralPath $item.source -Destination $dest -Force;if((Hash $dest) -ne $item.installed){throw 'Install verification failed'}}}
 catch{foreach($item in $plans){$dest=Target $item.path;if($item.original){Copy-Item -LiteralPath (Join-Path $backup $item.path) -Destination $dest -Force}elseif(Test-Path -LiteralPath $dest){Remove-Item -LiteralPath $dest}};throw}
 $state.status='installed';$state | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $statePath
 Write-Host 'Steam trainer + native hitboxes installed and verified. Start XIII normally; no separate viewer is needed.'
}catch{
 $message="Beta 7 $Action failed: $($_.Exception.Message)"
 try{$message | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'installer-error.txt')}catch{}
 Write-Host $message -ForegroundColor Red
 Write-Host 'Please send the error above, or installer-error.txt from the extracted package folder.'
 exit 1
}
